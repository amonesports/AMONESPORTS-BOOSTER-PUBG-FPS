#!/system/bin/sh
NAME="AMONESPORTS BOOSTER ULTIMATE"
VERSION="V4.5.1 STABIL"

MODPATH="${MODPATH:-${0%/*}}"
# shellcheck disable=SC1091
. "$MODPATH/fps_lib.sh"

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
SOC_HARDWARE=$(getprop ro.hardware)
SOC_PLATFORM=$(getprop ro.board.platform)

clear 2>/dev/null
ui_print " "
ui_print "╔════════════════════════════════════════════════╗"
ui_print "║       🚀 AMONESPORTS BOOSTER ULTIMATE 🚀       ║"
ui_print "║        De la gamer, pentru gameri! ✌️🔥        ║"
ui_print "╚════════════════════════════════════════════════╝"
ui_print " "
ui_print " 📋 INFORMAȚII SISTEM:"
ui_print "  ├─ 📱 Dispozitiv : ${DEVICE:-Necunoscut} (${MANUFACTURER:-Necunoscut})"
ui_print "  ├─ 🤖 Android Deținut   : ${ANDROIDVERSION:-Necunoscut}"
ui_print "  └─ ⚙️ Chipset (procesor) Deținut  : ${SOC_HARDWARE:-?} / ${SOC_PLATFORM:-?}"
ui_print " "

settings put global low_power 1 >/dev/null 2>&1
cmd power set-mode 0 >/dev/null 2>&1

sleep 2
fps_capture_orig_props

fps_cfg_read
FPS_VALID=0
case "$FPS" in
  ''|*[!0-9]*) FPS_VALID=0 ;;
  *)
    if [ "$FPS" -ge "$FPS_MIN_SANE" ] && [ "$FPS" -le "$FPS_MAX_SANE" ]; then
      FPS_VALID=1
    fi
    ;;
esac

ui_print " 🎯 CONFIGURARE RATĂ DE ÎMPROSPĂTARE:"
if [ "$FPS_VALID" -eq 1 ]; then
  FPS_FINAL="$FPS"
  ui_print "  ├─ 💾 Găsit configurare existentă: ${FPS_FINAL} Hz"
  ui_print "  └─ 💡 Sfat: O poți modifica din WebUI, nu prin reinstalare plugin."
else
  ui_print "  ├─ 🔍 Se detectează rata maximă a ecranului..."
  DETECTED_FPS="$(fps_detect)"
  if [ -n "$DETECTED_FPS" ]; then
    ui_print "  ├─ ✨ Detectat automat: ${DETECTED_FPS} Hz"
    FPS_FINAL="$DETECTED_FPS"
  else
    ui_print "  ├─ ⚠️ Detectare automată eșuată. Se alege manual..."
    pick_fps_manual
    FPS_FINAL="$FPS_PICKED"
    ui_print "  ├─ 👆 Selectat manual: ${FPS_FINAL} Hz"
  fi
  fps_cfg_write "$FPS_FINAL"
fi
ui_print " "

chmod 0644 "$MODPATH/module.prop" 2>/dev/null
mkdir -p "$FPS_PERSIST_DIR" 2>/dev/null

ui_print " 📦 INSTALARE FIȘIERE ȘI DAEMON:"
if [ -f "$MODPATH/bin/fps_daemon" ]; then
  cp -f "$MODPATH/bin/fps_daemon" "$FPS_DAEMON_BIN"
  chmod 755 "$FPS_DAEMON_BIN" 2>/dev/null
  ui_print "  ├─ ⚙️ Executabil Daemon: Instalat cu succes!"
else
  ui_print "  ├─ ⚠️ Fără daemon precompilat. Pune-l manual la:"
  ui_print "  │    └─ $FPS_DAEMON_BIN"
fi

cp -f "$MODPATH/fps_daemon_hook.sh" "$FPS_PERSIST_DIR/fps_daemon_hook.sh"
cp -f "$MODPATH/fps_lib.sh" "$FPS_PERSIST_DIR/fps_lib.sh"
chmod 755 "$FPS_PERSIST_DIR/fps_daemon_hook.sh" "$FPS_PERSIST_DIR/fps_lib.sh" 2>/dev/null

if [ ! -f "$FPS_GAMES_LIST" ] && [ -f "$MODPATH/gamelist.txt" ]; then
  cp -f "$MODPATH/gamelist.txt" "$FPS_GAMES_LIST"
  ui_print "  └─ 🎮 Listă de jocuri importată cu succes."
else
  ui_print "  └─ 🎮 Listă de jocuri existentă păstrată."
fi

sleep 3
ui_print " "
ui_print " 📌 RESUMAT CONFIGURARE:"
ui_print "  ├─ ⚡ Rată țintă       : ${FPS_FINAL} Hz"
ui_print "  ├─ 🤖 Daemon în fundal : Pornește la boot (activ doar în jocuri)"
ui_print "  ├─ 📁 Configurare      : $FPS_CFG"
ui_print "  └─ 🕹️ Listă jocuri     : $FPS_GAMES_LIST"
ui_print " "

sleep 1
ui_print " 💡 RECOMANDĂRI UTILE:"
ui_print "  ├─ 🗑️ Șterge arhivele/versiunile vechi ale modulului!"
ui_print "  └─ 📺 Dacă vezi pâlpâiri, repornește opțiunile de dezvoltator."
sleep 3

ui_print " "
ui_print " 🌐 Deschidere pagină suport & patch-uri..."
sleep 2
am start -a android.intent.action.VIEW -d "https://kode.amonesports.online" >/dev/null 2>&1
sleep 2

ui_print " "
ui_print " 🔎 VERIFICARE INTEGRITATE FIȘIERE:"
INSTALL_OK=1
check_deployed() {
  if [ -f "$1" ]; then
    ui_print "  ├─ [ ✅ OK ] ${1##*/}"
  else
    ui_print "  ├─ [ ❌ LIPSĂ ] ${1##*/}"
    INSTALL_OK=0
  fi
}
check_deployed "$FPS_PERSIST_DIR/fps_daemon_hook.sh"
check_deployed "$FPS_PERSIST_DIR/fps_lib.sh"
check_deployed "$FPS_CFG"
check_deployed "$FPS_GAMES_LIST"
if [ -f "$FPS_DAEMON_BIN" ]; then
  ui_print "  └─ [ ✅ OK ] ${FPS_DAEMON_BIN##*/}"
else
  ui_print "  └─ [ ⚠️ -- ] ${FPS_DAEMON_BIN##*/} (necesită compilare)"
fi
ui_print " "

if [ "$INSTALL_OK" -eq 1 ]; then
  ui_print " 🎉 SUCCES: Toate fișierele sunt la locul lor!"
  ui_print " 🔥 $NAME ($VERSION) instalat de AmonKode."
  cmd notification post -S bigtext -t 'AMONESPORTS BOOSTER ULTIMATE' 'amonkodebu' '✅ Plugin instalat cu succes! ℹ️ Daca telefonul se pune in modul Economisire Baterie însemnă că pluginu-ul este activat cu succes ✌🏻 ' >/dev/null 2>&1
else
  ui_print " ❌ EROARE: Unele fișiere lipsesc! Daemonul s-ar putea să nu ruleze."
  cmd notification post -S bigtext -t 'AMONESPORTS BOOSTER ULTIMATE' 'amonkodebu' '❌ Instalare eșuată! Verifică fișierele.' >/dev/null 2>&1
fi
ui_print "════════════════════════════════════════════════════"

