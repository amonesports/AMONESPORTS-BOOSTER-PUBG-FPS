#!/system/bin/sh
MODDIR="${0%/*}"
# shellcheck disable=SC1091
. "$MODDIR/fps_lib.sh"

fps_cfg_read
[ -n "$FPS" ] || FPS="$FPS_DEFAULT"

if [ -f "$FPS_STATE" ] && [ "$(cat "$FPS_STATE")" = "enabled" ]; then
  echo "...DEZACTIVARE DEBLOCARE FPS (AmonKode)..."
  sleep 1
  echo "...Te rugăm să aștepți. Procesul este în desfășurare..."
  fps_manual_off
  echo "Deblocare FPS DEZACTIVATĂ (s-au restaurat setările de bază + identitatea dispozitivului la ${FPS} Hz)"
  
  # Notificare pentru Dezactivare
  cmd notification post -S bigtext -t 'AMONESPORTS BOOSTER' 'Status' 'Plugin Dezactivat / Oprit!' > /dev/null 2>&1
else
  echo "...ACTIVARE DEBLOCARE FPS (${FPS} Hz) - AmonKode..."
  sleep 1
  echo "...Te rugăm să aștepți. Procesul este în desfășurare..."
  fps_manual_on
  echo "Deblocare FPS ACTIVATĂ la ${FPS} Hz"
  
  # Notificare pentru Activare
  cmd notification post -S bigtext -t 'AMONESPORTS BOOSTER ULTIMATE' 'Status' 'Plugin Activat cu succes !' > /dev/null 2>&1
fi

