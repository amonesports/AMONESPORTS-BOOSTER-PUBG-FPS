
#!/system/bin/sh
MODDIR="${0%/*}"
# shellcheck disable=SC1091
. "$MODDIR/fps_lib.sh"

until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
  sleep 2
done
sleep 5

fps_cfg_read
[ -n "$FPS" ] || FPS="$FPS_DEFAULT"
if [ -f "$FPS_OVERRIDE" ]; then
  fps_apply_on "$FPS"
else
  fps_apply_off "$FPS"
fi

fps_daemon_start
