/*
 * fps_daemon — per-game auto-trigger for the Unlock-FPS module.
 *
 * Watches which process sits in the "top-app" cpuset/cgroup (the same
 * group ActivityManager itself uses to mark the current foreground app
 * for scheduling priority) and shells out to fps_lib.sh's fps_apply_on /
 * fps_apply_off ONLY on an actual game<->non-game transition — never
 * inside the poll loop. The poll loop itself is a single file read +
 * string compare per tick: no fork/exec, no dumpsys, no binder IPC.
 *
 * Game whitelist is a plain text file, one package per line, reloaded
 * automatically when its mtime changes — no recompile needed to add or
 * remove games. Same pattern as SCRC's whitelist.txt.
 *
 * Build (on-device, Termux clang already targets this device's ABI):
 *   clang -O2 -Wall -o fps_daemon fps_daemon.c
 * or cross-compiled with the NDK:
 *   aarch64-linux-android30-clang -O2 -Wall -o fps_daemon fps_daemon.c
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/file.h>

#define PERSIST_DIR     "/data/local/tmp/amonkodebu"
#define GAMES_LIST      PERSIST_DIR "/games.list"
#define OVERRIDE_FILE   PERSIST_DIR "/manual_override"
#define PID_FILE        PERSIST_DIR "/daemon.pid"
#define STATUS_FILE     PERSIST_DIR "/daemon.status"
#define LOCK_FILE       PERSIST_DIR "/daemon.lock"
#define LOG_FILE        PERSIST_DIR "/daemon.log"
#define HOOK_SCRIPT     PERSIST_DIR "/fps_daemon_hook.sh"

#define POLL_INTERVAL_USEC   3500000  /* how often we read cgroup.procs, 3.5s */
#define EXIT_GRACE_SEC       4  /* debounce before reverting on exit     */
#define MAX_PKG_LEN         160
#define MAX_GAMES           256
#define MAX_PROCS            32

/*
 * Candidate paths for the "top-app" cpuset/cgroup. Layout differs
 * between cgroup v1 and v2 and across vendor kernels — first one that
 * exists and is readable wins. VERIFY ON YOUR DEVICE with:
 *   find /dev/cpuset /sys/fs/cgroup -iname 'top-app' 2>/dev/null
 * and add the real path here if none of these three match your kernel
 * (relevant since you're on a community GKI kernel, not stock).
 */
static const char *TOPAPP_CANDIDATES[] = {
    "/dev/cpuset/top-app/cgroup.procs",
    "/sys/fs/cgroup/top-app/cgroup.procs",
    "/dev/stune/top-app/tasks",
    NULL
};

static char games[MAX_GAMES][MAX_PKG_LEN];
static int  n_games = 0;
static time_t games_mtime = 0;

static char cur_topapp_path[256] = {0};
static volatile sig_atomic_t g_running = 1;

static void on_sigterm(int sig) { (void)sig; g_running = 0; }

static void log_line(const char *fmt, ...) {
    FILE *f = fopen(LOG_FILE, "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    fprintf(f, "[%02d:%02d:%02d] ", tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

/* Find which candidate path actually exists on this device; cache it. */
static int resolve_topapp_path(void) {
    if (cur_topapp_path[0]) return 1;
    for (int i = 0; TOPAPP_CANDIDATES[i]; i++) {
        if (access(TOPAPP_CANDIDATES[i], R_OK) == 0) {
            strncpy(cur_topapp_path, TOPAPP_CANDIDATES[i], sizeof(cur_topapp_path) - 1);
            log_line("using top-app path: %s", cur_topapp_path);
            return 1;
        }
    }
    return 0;
}

/* Reload games.list only if its mtime changed since the last read.
 * Format: one package name per line; blank lines and lines starting
 * with '#' are ignored. */
static void reload_games_if_changed(void) {
    struct stat st;
    if (stat(GAMES_LIST, &st) != 0) {
        if (n_games != 0) {
            n_games = 0;
            log_line("games.list missing, whitelist cleared");
        }
        return;
    }
    if (st.st_mtime == games_mtime) return;
    games_mtime = st.st_mtime;

    FILE *f = fopen(GAMES_LIST, "r");
    if (!f) return;
    n_games = 0;
    char line[MAX_PKG_LEN];
    while (n_games < MAX_GAMES && fgets(line, sizeof(line), f)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\0') continue;
        size_t len = strcspn(p, "\r\n");
        p[len] = '\0';
        if (len == 0) continue;
        strncpy(games[n_games], p, MAX_PKG_LEN - 1);
        games[n_games][MAX_PKG_LEN - 1] = '\0';
        n_games++;
    }
    fclose(f);
    log_line("games.list reloaded: %d entries", n_games);
}

static int is_game(const char *pkg) {
    for (int i = 0; i < n_games; i++)
        if (strcmp(games[i], pkg) == 0) return 1;
    return 0;
}

/* Read /proc/<pid>/cmdline -> package name. argv[0] is the process name
 * for Zygote-forked app processes. A trailing ":suffix" marks a
 * secondary process of the same package (e.g. com.foo.bar:push) —
 * normalized away so it still matches the base package in games.list. */
static int pid_to_pkg(int pid, char *out, size_t outsz) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    ssize_t n = read(fd, out, outsz - 1);
    close(fd);
    if (n <= 0) return -1;
    out[n] = '\0';
    char *colon = strchr(out, ':');
    if (colon) *colon = '\0';
    return 0;
}

/* Scan cgroup.procs and return the first package that's a known game
 * (out set to it), or otherwise the first resolvable package (so the
 * caller can still tell "foreground is something, just not a game"
 * apart from "couldn't read anything this tick"). */
static int get_foreground_pkg(char *out, size_t outsz) {
    out[0] = '\0';
    if (!resolve_topapp_path()) return -1;

    FILE *f = fopen(cur_topapp_path, "r");
    if (!f) {
        cur_topapp_path[0] = '\0'; /* force re-resolve next tick */
        return -1;
    }

    int pids[MAX_PROCS], np = 0;
    char line[32];
    while (np < MAX_PROCS && fgets(line, sizeof(line), f)) {
        int pid = atoi(line);
        if (pid > 0) pids[np++] = pid;
    }
    fclose(f);

    char pkg[MAX_PKG_LEN];
    char first[MAX_PKG_LEN] = {0};
    for (int i = 0; i < np; i++) {
        if (pid_to_pkg(pids[i], pkg, sizeof(pkg)) != 0) continue;
        if (!first[0]) strncpy(first, pkg, sizeof(first) - 1);
        if (is_game(pkg)) {
            strncpy(out, pkg, outsz - 1);
            return 0;
        }
    }
    strncpy(out, first, outsz - 1);
    return 0;
}

/* Fire fps_lib.sh's apply_on/apply_off via the hook script. Only ever
 * called on an actual state transition — this is the single place the
 * daemon forks a process. The hook's stdout/stderr go into daemon.log,
 * not /dev/null — otherwise a broken hook script silently "succeeds"
 * from our point of view and we only see a bare exit code.
 * pkg is the foreground package (may be "" if unknown) — threaded
 * through as argv[2] so fps_lib.sh can target per-package platform
 * calls (GameManagerService) instead of only device-wide props. */
static void run_hook(const char *mode, const char *pkg) {
    pid_t pid = fork();
    if (pid < 0) {
        log_line("fork failed: %s", strerror(errno));
        return;
    }
    if (pid == 0) {
        int devnull = open("/dev/null", O_RDONLY);
        if (devnull >= 0) dup2(devnull, 0);
        int logfd = open(LOG_FILE, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (logfd >= 0) {
            dup2(logfd, 1);
            dup2(logfd, 2);
        }
        execl("/system/bin/sh", "sh", HOOK_SCRIPT, mode, pkg, (char *)NULL);
        /* execl() only returns on failure */
        fprintf(stderr, "fps_daemon: execl(/system/bin/sh, %s, %s, %s) failed: %s\n",
                HOOK_SCRIPT, mode, pkg, strerror(errno));
        _exit(127);
    }
    int status = 0;
    waitpid(pid, &status, 0);
    log_line("hook %s(%s) -> exit %d", mode, pkg, WIFEXITED(status) ? WEXITSTATUS(status) : -1);
}

static void write_pidfile(void) {
    FILE *f = fopen(PID_FILE, "w");
    if (f) {
        fprintf(f, "%d\n", getpid());
        fclose(f);
    }
}

/* Self-reported heartbeat: PID, UID, and a timestamp updated every poll
 * tick. This is what the WebUI reads to decide "is it running" — not
 * kill(pid, 0) or /proc/<pid>, both of which require the checking
 * process to share (or exceed) the daemon's privilege level to succeed.
 * If the daemon runs as root and whatever invokes exec() in the WebUI
 * doesn't, those checks silently fail and misreport a live daemon as
 * dead. A plain world-readable file has no such requirement — any UID
 * that can read PERSIST_DIR can read this. Staleness (TS too old) means
 * "not running" just as reliably as a failed kill(), without needing to
 * signal or introspect another process at all. */
static void write_status(void) {
    FILE *f = fopen(STATUS_FILE, "w");
    if (f) {
        fprintf(f, "PID=%d\nDUID=%d\nTS=%ld\n", getpid(), (int)getuid(), (long)time(NULL));
        fclose(f);
    }
}

static void ensure_games_list_exists(void) {
    if (access(GAMES_LIST, F_OK) == 0) return;
    FILE *f = fopen(GAMES_LIST, "w");
    if (!f) return;
    fputs("# one package name per line, e.g.:\n# com.tencent.ig\n", f);
    fclose(f);
}

/* Advisory lock on LOCK_FILE, held for the entire process lifetime.
 * flock() locks belong to the *open file description*, which fork()
 * duplicates as a reference (not a copy) — so this survives the
 * double-fork daemonize dance below untouched, and is automatically
 * released by the kernel on ANY exit (including SIGKILL), no stale
 * pidfile-style cleanup needed. Deliberately acquired before the first
 * fork, so a second manual invocation refuses immediately and loudly on
 * its own terminal, rather than silently piling up a duplicate daemon
 * (which is exactly what happened when this was only enforced in the
 * shell wrapper and someone ran the binary directly for debugging). */
static int acquire_singleton_lock(void) {
    mkdir(PERSIST_DIR, 0755);
    int fd = open(LOCK_FILE, O_CREAT | O_RDWR, 0644);
    if (fd < 0) return -1;
    if (flock(fd, LOCK_EX | LOCK_NB) != 0) {
        close(fd);
        return -1;
    }
    return fd;
}

int main(void) {
    if (acquire_singleton_lock() < 0) {
        fprintf(stderr, "fps_daemon: another instance is already running (lock: %s)\n", LOCK_FILE);
        return 1;
    }

    /* daemonize: double fork + new session so we survive the parent
     * shell exiting and never reacquire a controlling tty */
    pid_t pid = fork();
    if (pid < 0) return 1;
    if (pid > 0) return 0;
    if (setsid() < 0) return 1;
    pid = fork();
    if (pid < 0) return 1;
    if (pid > 0) return 0;

    umask(0022);
    mkdir(PERSIST_DIR, 0755);
    close(0); close(1); close(2);
    open("/dev/null", O_RDONLY);
    open("/dev/null", O_WRONLY);
    open("/dev/null", O_WRONLY);

    signal(SIGTERM, on_sigterm);
    signal(SIGINT, on_sigterm);

    ensure_games_list_exists();
    write_pidfile();
    write_status();
    log_line("fps_daemon started, pid=%d, uid=%d", getpid(), (int)getuid());

    char cur_pkg[MAX_PKG_LEN] = {0};    /* package we last applied ON for */
    char last_seen[MAX_PKG_LEN] = {0};
    int applied = 0;
    int was_overridden = 0;
    time_t non_game_since = 0;

    while (g_running) {
        write_status();

        if (access(OVERRIDE_FILE, F_OK) == 0) {
            /* Manual override active (action.sh / WebUI toggle) — leave
             * whatever's currently applied alone. Don't even track "what
             * game is foreground" while paused, since that's meaningless
             * until we resume. */
            if (!was_overridden) {
                log_line("manual override active -> pausing automatic control");
                was_overridden = 1;
            }
            usleep(POLL_INTERVAL_USEC);
            continue;
        }
        if (was_overridden) {
            /* Override just lifted. The manual toggle already reverted
             * (or applied) tweaks on its own — our last-known applied/
             * cur_pkg is stale either way, so force a clean re-evaluation
             * on this tick instead of trusting pre-pause state. */
            log_line("manual override cleared -> resuming automatic control");
            applied = 0;
            cur_pkg[0] = '\0';
            non_game_since = 0;
            was_overridden = 0;
        }

        reload_games_if_changed();

        char fg[MAX_PKG_LEN];
        if (get_foreground_pkg(fg, sizeof(fg)) == 0 && fg[0]) {
            if (strcmp(fg, last_seen) != 0)
                strncpy(last_seen, fg, sizeof(last_seen) - 1);

            if (is_game(fg)) {
                non_game_since = 0;
                if (!applied || strcmp(fg, cur_pkg) != 0) {
                    log_line("game foreground: %s -> apply ON", fg);
                    run_hook("on", fg);
                    applied = 1;
                    strncpy(cur_pkg, fg, sizeof(cur_pkg) - 1);
                }
            } else if (applied) {
                if (non_game_since == 0) non_game_since = time(NULL);
                if (time(NULL) - non_game_since >= EXIT_GRACE_SEC) {
                    log_line("left game (%s) -> apply OFF", cur_pkg);
                    run_hook("off", cur_pkg);
                    applied = 0;
                    cur_pkg[0] = '\0';
                    non_game_since = 0;
                }
            }
        }
        /* get_foreground_pkg failing or returning empty just skips this
         * tick (e.g. screen off / top-app briefly empty) — state is left
         * as-is, no flapping. */

        usleep(POLL_INTERVAL_USEC);
    }

    if (applied) {
        log_line("shutting down while applied -> apply OFF");
        run_hook("off", cur_pkg);
    }
    log_line("fps_daemon stopped");
    unlink(PID_FILE);
    return 0;
}
