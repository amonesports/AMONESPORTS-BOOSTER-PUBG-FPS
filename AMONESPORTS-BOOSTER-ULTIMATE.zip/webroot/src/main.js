import { exec, toast } from "kernelsu";

const CFG_DIR       = "/data/local/tmp/amonkodebu";
const CFG_FILE      = `${CFG_DIR}/fps.cfg`;
const GAMES_FILE    = `${CFG_DIR}/games.list`;
const STATE_FILE    = `${CFG_DIR}/state`;
const OVERRIDE_FILE = `${CFG_DIR}/manual_override`;
const STATUS_FILE   = `${CFG_DIR}/daemon.status`;
const LOG_FILE      = `${CFG_DIR}/daemon.log`;
const DAEMON_BIN    = `${CFG_DIR}/fps_daemon`;
const LIB_SH        = `${CFG_DIR}/fps_lib.sh`;

const FPS_MIN = 30;
const FPS_MAX = 260;

const PKG_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;

const STR = {
  ro: {
    title: "AMONESPORTS BOOSTER ULTIMATE",
    hDaemon: "Demon (Daemon)",
    hManual: "Mod Manual (fără demon)",
    hFps: "Frecvență țintă (Hz)",
    hGames: "Listă jocuri",
    hLog: "Jurnal Demon (Log)",
    btnStart: "Pornește",
    btnStop: "Oprește",
    btnRestart: "Repornește",
    btnSave: "Salvează",
    btnAdd: "Adaugă",
    btnRefresh: "Actualizează lista",
    gamesPlaceholder: "un package name pe linie\nde exemplu:\ncom.tencent.ig\ncom.dts.freefireth",
    dash: "—",

    daemonLabel: "Demon:",
    tweaksLabel: "Tweak-uri active:",
    daemonRunning: (pid, uid) => `rulează (pid ${pid}, uid ${uid || "?"})`,
    daemonStopped: "oprit",
    stateEnabled: "activat",
    stateDisabled: "dezactivat",
    stateUnknown: "necunoscut",
    manualOn: "activat — demonul nu modifică tweak-urile până nu le dezactivezi tu",
    manualOff: "dezactivat — demonul controlează automat pe baza listei de jocuri",

    actioning: (a) => ({ start: "Pornire…", stop: "Oprire…", restart: "Repornire…" }[a] || `${a}…`),
    binMissing: (bin) => `✗ Binarul nu a fost găsit sau nu este executabil: ${bin}`,
    stillRunning: "✗ Încă rulează",
    stopped: "✓ Oprit",
    started: (pid, uid) => `✓ Rulează (pid ${pid}, uid ${uid || "?"})`,
    startFailed: (extra) => `✗ Pornirea a eșuat.${extra} Verifică bin/fps_daemon manual (su -c) și jurnalul de mai jos.`,

    turningOn: "Se activează…",
    turningOff: "Se dezactivează…",
    manualOnOk: "✓ Activat manual",
    manualOffOk: "✓ Dezactivat manual, demonul a preluat controlul",
    manualNotConfirmed: "✗ Neconfirmat — verifică jurnalul de mai jos",
    toastManualOn: "FPS unlock: manual ON",
    toastManualOff: "FPS unlock: manual OFF",

    fpsRange: (min, max) => `Introdu o valoare între ${min} și ${max}`,
    writing: "Se salvează…",
    fpsSavedOk: (expected) => `✓ Salvat și verificat: ${expected}`,
    toastFpsSaved: (v) => `FPS salvat: ${v} Hz`,
    fpsWriteFailed: (disk) => `✗ Salvarea nu a fost confirmată. Pe disc: "${disk}"`,
    toastFpsFailed: "Eroare la scrierea configurației",

    noValidPkg: "Nicio linie nu este un nume de pachet valid",
    empty: "Gol",
    addingGames: "Se adaugă…",
    gamesAddedOk: (n, skipped) =>
      `✓ Adăugat și verificat: ${n}` + (skipped ? ` (ignorate invalide: ${skipped})` : ""),
    toastGamesAdded: (n) => `Jocuri adăugate: ${n}`,
    gamesNotConfirmed: (list) => `✗ Neconfirmat: ${list}`,
    removingGame: (pkg) => `Se șterge ${pkg}…`,
    removedOk: (pkg) => `✓ Șters: ${pkg}`,
    removeFailed: (pkg) => `✗ Ștergerea a eșuat: ${pkg}`,
    gamesEmpty: "lista este goală",
    logEmpty: "(fără înregistrări)",
  },
  en: {
    title: "AMONESPORTS BOOSTER ULTIMATE",
    hDaemon: "Daemon",
    hManual: "Manual mode (no daemon)",
    hFps: "Target frequency (Hz)",
    hGames: "Game list",
    hLog: "Daemon log",
    btnStart: "Start",
    btnStop: "Stop",
    btnRestart: "Restart",
    btnSave: "Save",
    btnAdd: "Add",
    btnRefresh: "Refresh list",
    gamesPlaceholder: "one package name per line\ne.g.:\ncom.tencent.ig\ncom.dts.freefireth",
    dash: "—",
    daemonLabel: "Daemon:",
    tweaksLabel: "Tweaks now:",
    daemonRunning: (pid, uid) => `running (pid ${pid}, uid ${uid || "?"})`,
    daemonStopped: "not running",
    stateEnabled: "enabled",
    stateDisabled: "disabled",
    stateUnknown: "unknown",
    manualOn: "on — the daemon leaves tweaks alone until you turn this off",
    manualOff: "off — the daemon controls tweaks by the game list",
    actioning: (a) => ({ start: "Starting…", stop: "Stopping…", restart: "Restarting…" }[a] || `${a}…`),
    binMissing: (bin) => `✗ Binary missing or not executable: ${bin}`,
    stillRunning: "✗ Still running",
    stopped: "✓ Stopped",
    started: (pid, uid) => `✓ Running (pid ${pid}, uid ${uid || "?"})`,
    startFailed: (extra) => `✗ Failed to start.${extra} Check bin/fps_daemon manually (su -c) and the log below.`,
    turningOn: "Turning on…",
    turningOff: "Turning off…",
    manualOnOk: "✓ Turned on manually",
    manualOffOk: "✓ Turned off, the daemon is back in control",
    manualNotConfirmed: "✗ Not confirmed — check the log below",
    toastManualOn: "FPS unlock: manual ON",
    toastManualOff: "FPS unlock: manual OFF",
    fpsRange: (min, max) => `Enter a number from ${min} to ${max}`,
    writing: "Saving…",
    fpsSavedOk: (expected) => `✓ Saved and verified: ${expected}`,
    toastFpsSaved: (v) => `FPS saved: ${v} Hz`,
    fpsWriteFailed: (disk) => `✗ Write not confirmed. On disk: "${disk}"`,
    toastFpsFailed: "Failed to write config",
    noValidPkg: "No line looks like a package name",
    empty: "Empty",
    addingGames: "Adding…",
    gamesAddedOk: (n, skipped) => `✓ Added and verified: ${n}` + (skipped ? ` (skipped invalid: ${skipped})` : ""),
    toastGamesAdded: (n) => `Games added: ${n}`,
    gamesNotConfirmed: (list) => `✗ Not confirmed: ${list}`,
    removingGame: (pkg) => `Removing ${pkg}…`,
    removedOk: (pkg) => `✓ Removed: ${pkg}`,
    removeFailed: (pkg) => `✗ Failed to remove: ${pkg}`,
    gamesEmpty: "list is empty",
    logEmpty: "(empty)",
  },
  ru: {
    title: "AMONESPORTS BOOSTER ULTIMATE",
    hDaemon: "Daemon",
    hManual: "Ручной режим (без демона)",
    hFps: "Целевая частота (Hz)",
    hGames: "Список игр",
    hLog: "Лог демона",
    btnStart: "Start",
    btnStop: "Stop",
    btnRestart: "Restart",
    btnSave: "Сохранить",
    btnAdd: "Добавить",
    btnRefresh: "Обновить список",
    gamesPlaceholder: "один package name на строку\nнапример:\ncom.tencent.ig\ncom.dts.freefireth",
    dash: "—",
    daemonLabel: "Демон:",
    tweaksLabel: "Твики сейчас:",
    daemonRunning: (pid, uid) => `запущен (pid ${pid}, uid ${uid || "?"})`,
    daemonStopped: "не запущен",
    stateEnabled: "включено",
    stateDisabled: "выключено",
    stateUnknown: "неизвестно",
    manualOn: "включён — демон не трогает твики, пока ты не выключишь сам",
    manualOff: "выключен — управляет демон по списку игр",
    actioning: (a) => ({ start: "Запуск…", stop: "Остановка…", restart: "Перезапуск…" }[a] || `${a}…`),
    binMissing: (bin) => `✗ Бинарник не найден или не исполняемый: ${bin}`,
    stillRunning: "✗ Всё ещё запущен",
    stopped: "✓ Остановлен",
    started: (pid, uid) => `✓ Запущен (pid ${pid}, uid ${uid || "?"})`,
    startFailed: (extra) => `✗ Не запустился.${extra} Проверь bin/fps_daemon вручную (su -c) и лог ниже.`,
    turningOn: "Включаю…",
    turningOff: "Выключаю…",
    manualOnOk: "✓ Включено вручную",
    manualOffOk: "✓ Выключено, демон снова рулит сам",
    manualNotConfirmed: "✗ Не подтвердилось — проверь лог ниже",
    toastManualOn: "FPS unlock: ручной ON",
    toastManualOff: "FPS unlock: ручной OFF",
    fpsRange: (min, max) => `Введи число от ${min} до ${max}`,
    writing: "Записываю…",
    fpsSavedOk: (expected) => `✓ Сохранено и проверено: ${expected}`,
    toastFpsSaved: (v) => `FPS сохранён: ${v} Hz`,
    fpsWriteFailed: (disk) => `✗ Запись не подтвердилась. На диске: "${disk}"`,
    toastFpsFailed: "Ошибка записи конфига",
    noValidPkg: "Ни одна строка не похожа на package name",
    empty: "Пусто",
    addingGames: "Добавляю…",
    gamesAddedOk: (n, skipped) => `✓ Добавлено и проверено: ${n}` + (skipped ? ` (пропущено некорректных: ${skipped})` : ""),
    toastGamesAdded: (n) => `Добавлено игр: ${n}`,
    gamesNotConfirmed: (list) => `✗ Не подтвердилось: ${list}`,
    removingGame: (pkg) => `Удаляю ${pkg}…`,
    removedOk: (pkg) => `✓ Удалено: ${pkg}`,
    removeFailed: (pkg) => `✗ Не удалилось: ${pkg}`,
    gamesEmpty: "список пуст",
    logEmpty: "(пусто)",
  }
};

let lang = localStorage.getItem("fps_lang");
if (lang !== "ro" && lang !== "en" && lang !== "ru") lang = "ro";

function t(key, ...args) {
  const v = STR[lang][key];
  return typeof v === "function" ? v(...args) : v;
}

function stateLabel(v) {
  if (v === "enabled") return t("stateEnabled");
  if (v === "disabled") return t("stateDisabled");
  return t("stateUnknown");
}

function applyStaticTranslations() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll(".lang-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.lang === lang);
  });
}

function setLanguage(newLang) {
  if (newLang === lang) return;
  lang = newLang;
  localStorage.setItem("fps_lang", lang);
  applyStaticTranslations();
  refreshDaemonDiag();
  renderGames();
  refreshLog();
}

const $ = (id) => document.getElementById(id);

function setStatus(el, kind, text) {
  el.className = `status ${kind}`;
  el.textContent = text;
}

async function run(cmd) {
  const { errno, stdout, stderr } = await exec(cmd);
  return { ok: errno === 0, stdout: (stdout || "").trim(), stderr: (stderr || "").trim() };
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function refreshDaemonDiag() {
  const hb = await run(
    `PID=0; DUID=0; TS=0; [ -f '${STATUS_FILE}' ] && . '${STATUS_FILE}' 2>/dev/null; NOW=$(date +%s 2>/dev/null || echo 0); echo "$PID|$DUID|$((NOW-TS))"`
  );
  let [pid, uid, age] = hb.stdout.split("|");
  let isRunning = Number.isFinite(Number(age)) && Number(age) <= 15;

  if (!isRunning) {
    const lg = await run(`grep -E 'fps_daemon (started|stopped)' '${LOG_FILE}' 2>/dev/null | tail -n 1`);
    if (lg.stdout.includes("started")) {
      isRunning = true;
      const m = lg.stdout.match(/pid=(\d+)(?:,\s*uid=(\d+))?/);
      if (m) {
        pid = m[1];
        if (m[2]) uid = m[2];
      }
    }
  }

  const st = await run(`cat '${STATE_FILE}' 2>/dev/null || echo unknown`);
  const applied = st.stdout || "unknown";

  const ov = await run(`[ -f '${OVERRIDE_FILE}' ] && echo 1 || echo 0`);
  const override = ov.stdout;

  const el = $("daemonDiag");
  el.innerHTML = `
    ${t("daemonLabel")} <span class="badge ${isRunning ? "on" : "off"}">${
    isRunning ? t("daemonRunning", pid, uid) : t("daemonStopped")
  }</span><br>
    ${t("tweaksLabel")} <span class="badge ${applied === "enabled" ? "on" : "off"}">${stateLabel(applied)}</span>
  `;

  const toggle = $("manualToggle");
  toggle.checked = override === "1";
  $("manualLabel").textContent = override === "1" ? t("manualOn") : t("manualOff");

  return { isRunning, pid, uid, applied, override };
}

async function daemonAction(action) {
  const statusEl = $("daemonStatus");
  setStatus(statusEl, "pending", t("actioning", action));

  if (action === "start" || action === "restart") {
    const { stdout } = await run(`[ -x '${DAEMON_BIN}' ] && echo yes || echo no`);
    if (stdout !== "yes") {
      setStatus(statusEl, "err", t("binMissing", DAEMON_BIN));
      return;
    }
  }

  const cmd = {
    start:   `. '${LIB_SH}'; fps_daemon_start`,
    stop:    `. '${LIB_SH}'; fps_daemon_stop`,
    restart: `. '${LIB_SH}'; fps_daemon_stop; fps_daemon_start`,
  }[action];

  const { ok, stderr } = await run(cmd);

  let diag = null;
  for (let i = 0; i < 6; i++) {
    await sleep(500);
    diag = await refreshDaemonDiag();
    if (action === "stop" ? !diag.isRunning : diag.isRunning) break;
  }

  if (action === "stop") {
    setStatus(statusEl, diag.isRunning ? "err" : "ok", diag.isRunning ? t("stillRunning") : t("stopped"));
    return;
  }

  if (diag.isRunning) {
    setStatus(statusEl, "ok", t("started", diag.pid, diag.uid));
  } else {
    setStatus(statusEl, "err", t("startFailed", !ok && stderr ? ` ${stderr}` : ""));
  }
}

async function manualToggleChanged(turnOn) {
  const statusEl = $("manualStatus");
  const toggle = $("manualToggle");
  toggle.disabled = true;
  setStatus(statusEl, "pending", turnOn ? t("turningOn") : t("turningOff"));

  await run(`. '${LIB_SH}'; ${turnOn ? "fps_manual_on" : "fps_manual_off"}`);

  const wantOverride = turnOn ? "1" : "0";
  let diag = null;
  let confirmed = false;
  for (let i = 0; i < 15; i++) {
    await sleep(700);
    diag = await refreshDaemonDiag();
    if (diag.override === wantOverride) {
      confirmed = true;
      break;
    }
  }

  if (!confirmed) {
    const lg = await run(`grep -E 'manual override (active|cleared)' '${LOG_FILE}' 2>/dev/null | tail -n 1`);
    if (turnOn && lg.stdout.includes("active")) confirmed = true;
    if (!turnOn && lg.stdout.includes("cleared")) confirmed = true;
  }

  if (confirmed) {
    setStatus(statusEl, "ok", turnOn ? t("manualOnOk") : t("manualOffOk"));
    toast(turnOn ? t("toastManualOn") : t("toastManualOff"));
    toggle.checked = turnOn;
  } else {
    setStatus(statusEl, "err", t("manualNotConfirmed"));
    toggle.checked = diag.override === "1";
  }
  toggle.disabled = false;
}

async function loadFps() {
  const { stdout } = await run(`cat '${CFG_FILE}' 2>/dev/null`);
  const m = stdout.match(/FPS=(\d+)/);
  if (m) $("fpsInput").value = m[1];
}

async function saveFps() {
  const statusEl = $("fpsStatus");
  const raw = $("fpsInput").value;
  const value = parseInt(raw, 10);

  if (!Number.isFinite(value) || value < FPS_MIN || value > FPS_MAX) {
    setStatus(statusEl, "err", t("fpsRange", FPS_MIN, FPS_MAX));
    return;
  }

  setStatus(statusEl, "pending", t("writing"));
  const expected = `FPS=${value}`;
  await run(
    `mkdir -p '${CFG_DIR}' 2>/dev/null; printf '%s\\n' '${expected}' > '${CFG_FILE}' && chmod 666 '${CFG_FILE}'`
  );

  const { stdout } = await run(`cat '${CFG_FILE}' 2>/dev/null`);
  if (stdout.trim() === expected) {
    setStatus(statusEl, "ok", t("fpsSavedOk", expected));
    toast(t("toastFpsSaved", value));
  } else {
    setStatus(statusEl, "err", t("fpsWriteFailed", stdout || t("dash")));
    toast(t("toastFpsFailed"));
  }
}

async function loadGames() {
  const { stdout } = await run(`cat '${GAMES_FILE}' 2>/dev/null`);
  return stdout
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"));
}

async function renderGames() {
  const listEl = $("gamesList");
  const games = await loadGames();
  listEl.innerHTML = "";
  if (games.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.style.justifyContent = "center";
    li.textContent = t("gamesEmpty");
    listEl.appendChild(li);
    return;
  }
  for (const pkg of games) {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = pkg;
    const btn = document.createElement("button");
    btn.textContent = "×";
    btn.onclick = () => removeGame(pkg);
    li.append(span, btn);
    listEl.appendChild(li);
  }
}

async function addGames() {
  const statusEl = $("gamesStatus");
  const raw = $("gamesInput").value;
  const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);

  const valid = [...new Set(lines.filter((l) => PKG_RE.test(l)))];
  const invalid = lines.filter((l) => !PKG_RE.test(l));

  if (valid.length === 0) {
    setStatus(statusEl, "err", invalid.length ? t("noValidPkg") : t("empty"));
    return;
  }

  setStatus(statusEl, "pending", t("addingGames"));
  const script = valid
    .map((p) => `grep -qxF '${p}' '${GAMES_FILE}' 2>/dev/null || echo '${p}' >> '${GAMES_FILE}'`)
    .join("; ");
  await run(`mkdir -p '${CFG_DIR}' 2>/dev/null; touch '${GAMES_FILE}'; ${script}; chmod 666 '${GAMES_FILE}'`);

  const after = await loadGames();
  const missing = valid.filter((p) => !after.includes(p));

  if (missing.length === 0) {
    setStatus(statusEl, "ok", t("gamesAddedOk", valid.length, invalid.length));
    $("gamesInput").value = "";
    toast(t("toastGamesAdded", valid.length));
  } else {
    setStatus(statusEl, "err", t("gamesNotConfirmed", missing.join(", ")));
  }
  await renderGames();
}

async function removeGame(pkg) {
  const statusEl = $("gamesStatus");
  setStatus(statusEl, "pending", t("removingGame", pkg));
  await run(`grep -vxF '${pkg}' '${GAMES_FILE}' > '${GAMES_FILE}.tmp' 2>/dev/null && mv '${GAMES_FILE}.tmp' '${GAMES_FILE}'`);

  const after = await loadGames();
  if (!after.includes(pkg)) {
    setStatus(statusEl, "ok", t("removedOk", pkg));
  } else {
    setStatus(statusEl, "err", t("removeFailed", pkg));
  }
  await renderGames();
}

async function refreshLog() {
  const box = $("logBox");
  const { stdout } = await run(`tail -n 40 '${LOG_FILE}' 2>/dev/null`);
  box.textContent = stdout || t("logEmpty");
  box.scrollTop = box.scrollHeight;
}

window.addEventListener("DOMContentLoaded", () => {
  applyStaticTranslations();

  $("fpsSave").onclick = saveFps;
  $("gamesAdd").onclick = addGames;
  $("gamesRefresh").onclick = renderGames;
  $("daemonStart").onclick = () => daemonAction("start");
  $("daemonStop").onclick = () => daemonAction("stop");
  $("daemonRestart").onclick = () => daemonAction("restart");
  $("manualToggle").addEventListener("change", (e) => manualToggleChanged(e.target.checked));
  document.querySelectorAll(".lang-btn").forEach((b) => {
    b.onclick = () => setLanguage(b.dataset.lang);
  });

  refreshDaemonDiag();
  loadFps();
  renderGames();
  refreshLog();
  setInterval(refreshDaemonDiag, 4000);
  setInterval(refreshLog, 4000);
});

