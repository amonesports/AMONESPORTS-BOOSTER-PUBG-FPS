(() => {
  // node_modules/kernelsu/dist/index.js
  async function exec(cmd) {
    if (window.ksu && typeof window.ksu.exec === "function") {
      return new Promise((resolve) => {
        const callbackName = "ksu_cb_" + Math.random().toString(36).substring(2, 9);
        window[callbackName] = (errno, stdout, stderr) => {
          delete window[callbackName];
          resolve({ errno, stdout, stderr });
        };
        window.ksu.exec(cmd, callbackName);
      });
    }
    return { errno: -1, stdout: "", stderr: "KernelSU bridge not found" };
  }

  function toast(msg) {
    if (window.ksu && typeof window.ksu.toast === "function") {
      window.ksu.toast(msg);
    } else {
      console.log("[Toast]:", msg);
      showWebToast(msg);
    }
  }
  window.toast = toast;

  // Notificare pop-up vizuală în interfață (Web Toast)
  function showWebToast(message) {
    let container = document.getElementById("toastContainer");
    if (!container) {
      container = document.createElement("div");
      container.id = "toastContainer";
      container.style.cssText = "position:fixed; bottom:20px; left:50%; transform:translateX(-50%); z-index:10000; display:flex; flex-direction:column; gap:8px; pointer-events:none;";
      document.body.appendChild(container);
    }
    const tEl = document.createElement("div");
    tEl.style.cssText = "background:rgba(14,4,6,0.95); border:1px solid #ff0033; color:#fff; padding:10px 16px; border-radius:10px; font-size:11px; font-weight:700; box-shadow:0 0 15px rgba(255,0,51,0.5); pointer-events:auto; transition:opacity 0.3s ease;";
    tEl.textContent = message;
    container.appendChild(tEl);
    setTimeout(() => {
      tEl.style.opacity = "0";
      setTimeout(() => tEl.remove(), 300);
    }, 3000);
  }

  // src/main.js
  const CFG_DIR = "/data/local/tmp/amonkodebu";
  const CFG_FILE = `${CFG_DIR}/fps.cfg`;
  const GAMES_FILE = `${CFG_DIR}/games.list`;
  const STATE_FILE = `${CFG_DIR}/state`;
  const OVERRIDE_FILE = `${CFG_DIR}/manual_override`;
  const STATUS_FILE = `${CFG_DIR}/daemon.status`;
  const LOG_FILE = `${CFG_DIR}/daemon.log`;
  const DAEMON_BIN = `${CFG_DIR}/fps_daemon`;
  const LIB_SH = `${CFG_DIR}/fps_lib.sh`;

  const FPS_MIN = 30;
  const FPS_MAX = 260;
  const PKG_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;

  // LISTĂ PREDEFINITĂ DE JOCURI POPULARE
  const PRESET_GAMES = [
    { name: "Mobile Legends: Bang Bang", pkg: "com.mobile.legends" },
    { name: "PUBG Mobile", pkg: "com.tencent.ig" },
    { name: "Call of Duty: Mobile", pkg: "com.activision.callofduty.shooter" },
    { name: "Free Fire", pkg: "com.dts.freefireth" },
    { name: "Free Fire MAX", pkg: "com.dts.freefiremax" },
    { name: "League of Legends: Wild Rift", pkg: "com.riotgames.league.wildrift" },
    { name: "Genshin Impact", pkg: "com.miHoYo.GenshinImpact" },
    { name: "Honkai: Star Rail", pkg: "com.HoYoverse.hkrpgoversea" },
    { name: "Standoff 2", pkg: "com.axlebolt.standoff2" },
    { name: "Roblox", pkg: "com.roblox.client" },
    { name: "Brawl Stars", pkg: "com.supercell.brawlstars" },
    { name: "eFootball 2024", pkg: "jp.konami.pesam" },
    { name: "Arena of Valor", pkg: "com.garena.game.kgtw" },
    { name: "EA SPORTS FC Mobile", pkg: "com.ea.gp.fifamobile" }
  ];

  const STR = {
    ro: {
      title: 'AMONESPORTS <span style="color: #ff2a2a; font-weight: bold;">BOOSTER ULTIMATE</span>',
      sysActive: "Sistem Activ (ON)",
      sysInactive: "Sistem Oprit (OFF)",
      hDaemon: "Demon (Daemon)",
      hManual: "Mod Manual (Fără demon)",
      hFps: "Setare Rapidă FPS (Limitator Hz)",
      hGames: "Bifează Jocuri pentru Unlocking",
      gamesDesc: "Numele pachetului (ex: com.mobile.legends)",
      hLog: "Jurnal Evenimente (Log)",
      hBrand: "Brand Smartphone",
      hCpu: "Arhitectură Procesor (Chipset)",
      hRamSize: "Capacitate Memorie RAM",
      hRamType: "Generație Memorie RAM",
      hThermal: "Performanță CPU & Control Termic",
      hNet: "Optimizare Rețea & Ping (Network Boost)",
      hActions: "Acțiuni Rapide",
      lblBrand: "Producător Dispozitiv",
      descBrand: "Selectează brandul de telefon",
      lblCpu: "Tip Chipset CPU/GPU",
      descCpu: "Optimizare specifică pe nuclee",
      lblRamSize: "Cantitate RAM Disponibilă",
      descRamSize: "Alege memoria RAM a dispozitivului",
      lblRamType: "Tip / Tehnologie LPDDR",
      descRamType: "Frecvență și lățime de bandă RAM",
      lblProfile: "Profil de Rulare & GHz",
      descProfile: "Previne supraîncălzirea / Setează putere",
      lblNetBoost: "Stare Net Boost",
      descNetBoost: "Reduce latența și prioritizează pachetele UDP",
      lblDns: "DNS Gaming & TCP Tweaks",
      descDns: "Activează flux rapid de date (Cloudflare / Google)",
      lblPkgList: "Pachete Active Pe Disc",
      lblFpsTarget: "Selectează Cadre pe Secundă",
      descFpsTarget: "Plafon cadrelor / Refresh rate hardware",
      descDesc: "Control hardware real-time, frecvențe GHz, Net Boost & Thermal Guard.",
      btnApplyAll: "⚡ Setează Hardware & Aplică",
      btnStart: "Pornește",
      btnStop: "Oprește",
      btnRestart: "Repornește",
      btnSave: "OK",
      btnAdd: "Adaugă",
      btnApply: "Aplică",
      modalSelect: "Selectează Opțiunea",
      btnRefresh: "Actualizează lista",
      gamesPlaceholder: "ex: com.mobile.legends",
      dash: "—",
      daemonLabel: "Demon:",
      tweaksLabel: "Tweak-uri active:",
      daemonRunning: (pid, uid) => `rulează (pid ${pid}, uid ${uid || "?"})`,
      daemonStopped: "oprit",
      stateEnabled: "activat",
      stateDisabled: "dezactivat",
      stateUnknown: "necunoscut",
      manualOn: "activat — demonul nu modifică tweak-urile până nu le dezactivezi tu",
      manualOff: "dezactivat — demonul controlează automat pe baza listei de jocuri",
      actioning: (a) => ({ start: "Pornire…", stop: "Oprire…", restart: "Repornire…" }[a] || `${a}…`),
      binMissing: (bin) => `✗ Binarul nu a fost găsit sau nu este executabil: ${bin}`,
      stillRunning: "✗ Încă rulează",
      stopped: "✓ Oprit",
      started: (pid, uid) => `✓ Rulează (pid ${pid}, uid ${uid || "?"})`,
      startFailed: (extra) => `✗ Pornirea a eșuat.${extra} Verifică bin/fps_daemon manual (su -c) și jurnalul de mai jos.`,
      turningOn: "Se activează…",
      turningOff: "Se dezactivează…",
      manualOnOk: "✓ Activat manual",
      manualOffOk: "✓ Dezactivat manual, demonul a preluat controlul",
      manualNotConfirmed: "✗ Neconfirmat — verifică jurnalul de mai jos",
      toastManualOn: "FPS unlock: manual ON",
      toastManualOff: "FPS unlock: manual OFF",
      fpsRange: (min, max) => `Introdu o valoare între ${min} și ${max}`,
      writing: "Se salvează…",
      fpsSavedOk: (expected) => `✓ Salvat și verificat: ${expected}`,
      toastFpsSaved: (v) => `FPS salvat: ${v} Hz`,
      fpsWriteFailed: (disk) => `✗ Salvarea nu a fost confirmată. Pe disc: "${disk}"`,
      toastFpsFailed: "Eroare la scrierea configurației",
      noValidPkg: "Nicio linie nu este un nume de pachet valid",
      empty: "Gol",
      addingGames: "Se adaugă…",
      gamesAddedOk: (n, skipped) => `✓ Adăugat și verificat: ${n}` + (skipped ? ` (ignorate invalide: ${skipped})` : ""),
      toastGamesAdded: (n) => `Jocuri adăugate: ${n}`,
      gamesNotConfirmed: (list) => `✗ Neconfirmat: ${list}`,
      removingGame: (pkg) => `Se șterge ${pkg}…`,
      removedOk: (pkg) => `✓ Șters: ${pkg}`,
      removeFailed: (pkg) => `✗ Ștergerea a eșuat: ${pkg}`,
      gamesEmpty: "lista este goală",
      logEmpty: "(fără înregistrări)",
      hPopularGames: "Jocuri Populare Suportate",
      hSaveChecked: "💾 Salvează Lista Bifată",
      hAddCustom: "Adaugă Joc Custom (Pachet manual)",
      hCustomHz: "Valoare Personalizată Hz",
      listUpdated: (n) => `Lista actualizată: ${n} jocuri salvate.`,
      langChanged: "Limbă schimbată în Română",
      toastGameSelected: (name) => `Ai selectat jocul: ${name}`,
      toastGameRemoved: (pkg) => `Joc șters: ${pkg}`,
      toastFpsRefresh: (val) => `Ai setat refresh rate: ${val} Hz`,
      toastSetting: (name, state) => `${name}: ${state}`,
      toastProductSelected: (text) => `Ai selectat produs/opțiune: ${text}`,
      toastHwConfig: (brand) => `Hardware configurat pentru ${brand}!`,
      logFps: (val) => `[FPS Limiter] Frecvență țintă setată la ${val} Hz.`,
      logTweaks: (name, state) => `[Tweaks] ${name} a fost ${state}.`,
      logOpt: (text) => `[Optimizare] Setați parametrii: ${text}`,
      logAppStart: "[⚡] Se aplică parametrii hardware & profilele termice...",
      logAppSuccess: (brand, cpu) => `[✔] Configurație aplicată cu succes pentru ${brand} (${cpu})!`,
      // Listele traduse pentru modaluri
      brandList: {
        samsung: "Samsung", redmagic: "ZTE Nubia RedMagic", rogphone: "Asus RogPhone",
        xiaomi: "Xiaomi / Redmi", poco: "POCO", oppo: "Oppo", oneplus: "OnePlus",
        vivo: "Vivo", huawei: "Huawei", honor: "Honor", nokia: "Nokia",
        realme: "Realme", nothing: "Nothing Phone", sony: "Sony", motorola: "Motorola",
        ihunt: "iHunt", sharp: "Sharp Aquos", other: "Universal / Altul"
      },
      cpuList: {
        snapdragon: "Qualcomm Snapdragon", mediatek: "MediaTek Dimensity / Helio",
        exynos: "Samsung Exynos", kirin: "Huawei Kirin", tensor: "Google Tensor"
      },
      profileList: {
        powersave: "Baterie / Eco (salvare baterie)",
        balanced_gaming: "Performanță (stabilitate medie)",
        performance: "Gaming Intensiv (pentru sesiunile lungi de gaming)",
        turbo: "Turbo / Extreme (ai nevoie de răcire activă)"
      }
    },
    en: {
      title: 'AMONESPORTS <span style="color: #ff2a2a; font-weight: bold;">BOOSTER ULTIMATE</span>',
      sysActive: "System Active (ON)",
      sysInactive: "System Stopped (OFF)",
      hDaemon: "Daemon",
      hManual: "Manual Mode (No daemon)",
      hFps: "Quick FPS Setter (Hz Limiter)",
      hGames: "Check Games for Unlocking",
      gamesDesc: "Package name (e.g.: com.mobile.legends)",
      hLog: "Event Log",
      hBrand: "Smartphone Brand",
      hCpu: "Processor Architecture (Chipset)",
      hRamSize: "RAM Memory Capacity",
      hRamType: "RAM Generation",
      hThermal: "CPU Performance & Thermal Control",
      hNet: "Network Optimization & Ping (Network Boost)",
      hActions: "Quick Actions",
      lblBrand: "Device Manufacturer",
      descBrand: "Select phone brand",
      lblCpu: "CPU/GPU Chipset Type",
      descCpu: "Core-specific optimization",
      lblRamSize: "Available RAM Capacity",
      descRamSize: "Choose device RAM memory",
      lblRamType: "LPDDR Type / Technology",
      descRamType: "RAM frequency and bandwidth",
      lblProfile: "Execution Profile & GHz",
      descProfile: "Prevents overheating / Sets power",
      lblNetBoost: "Net Boost Status",
      descNetBoost: "Lowers latency and prioritizes UDP packets",
      lblDns: "Gaming DNS & TCP Tweaks",
      descDns: "Enables fast data stream (Cloudflare / Google)",
      lblPkgList: "Active Packages on Disk",
      lblFpsTarget: "Select Frames Per Second",
      descFpsTarget: "Frame cap / Hardware refresh rate",
      descDesc: "Real-time hardware control, GHz clock rates, Net Boost & Thermal Guard.",
      btnApplyAll: "⚡ Set Hardware & Apply",
      btnStart: "Start",
      btnStop: "Stop",
      btnRestart: "Restart",
      btnSave: "OK",
      btnAdd: "Add",
      btnApply: "Apply",
      modalSelect: "Select Option",
      btnRefresh: "Refresh List",
      gamesPlaceholder: "e.g.: com.mobile.legends",
      dash: "—",
      daemonLabel: "Daemon:",
      tweaksLabel: "Active tweaks:",
      daemonRunning: (pid, uid) => `running (pid ${pid}, uid ${uid || "?"})`,
      daemonStopped: "not running",
      stateEnabled: "enabled",
      stateDisabled: "disabled",
      stateUnknown: "unknown",
      manualOn: "on — the daemon leaves tweaks alone until you turn this off",
      manualOff: "off — the daemon controls tweaks by the game list",
      actioning: (a) => ({ start: "Starting…", stop: "Stopping…", restart: "Restarting…" }[a] || `${a}…`),
      binMissing: (bin) => `✗ Binary missing or not executable: ${bin}`,
      stillRunning: "✗ Still running",
      stopped: "✓ Stopped",
      started: (pid, uid) => `✓ Running (pid ${pid}, uid ${uid || "?"})`,
      startFailed: (extra) => `✗ Failed to start.${extra} Check bin/fps_daemon manually (su -c) and the log below.`,
      turningOn: "Turning on…",
      turningOff: "Turning off…",
      manualOnOk: "✓ Turned on manually",
      manualOffOk: "✓ Turned off, the daemon is back in control",
      manualNotConfirmed: "✗ Not confirmed — check the log below",
      toastManualOn: "FPS unlock: manual ON",
      toastManualOff: "FPS unlock: manual OFF",
      fpsRange: (min, max) => `Enter a number from ${min} to ${max}`,
      writing: "Saving…",
      fpsSavedOk: (expected) => `✓ Saved and verified: ${expected}`,
      toastFpsSaved: (v) => `FPS saved: ${v} Hz`,
      fpsWriteFailed: (disk) => `✗ Write not confirmed. On disk: "${disk}"`,
      toastFpsFailed: "Failed to write config",
      noValidPkg: "No line looks like a package name",
      empty: "Empty",
      addingGames: "Adding…",
      gamesAddedOk: (n, skipped) => `✓ Added and verified: ${n}` + (skipped ? ` (skipped invalid: ${skipped})` : ""),
      toastGamesAdded: (n) => `Games added: ${n}`,
      gamesNotConfirmed: (list) => `✗ Not confirmed: ${list}`,
      removingGame: (pkg) => `Removing ${pkg}…`,
      removedOk: (pkg) => `✓ Removed: ${pkg}`,
      removeFailed: (pkg) => `✗ Failed to remove: ${pkg}`,
      gamesEmpty: "list is empty",
      logEmpty: "(empty)",
      hPopularGames: "Supported Popular Games",
      hSaveChecked: "💾 Save Checked List",
      hAddCustom: "Add Custom Game (Manual package)",
      hCustomHz: "Custom Hz Value",
      listUpdated: (n) => `List updated: ${n} games saved.`,
      langChanged: "Language switched to English",
      toastGameSelected: (name) => `Selected game: ${name}`,
      toastGameRemoved: (pkg) => `Game removed: ${pkg}`,
      toastFpsRefresh: (val) => `Refresh rate set to: ${val} Hz`,
      toastSetting: (name, state) => `${name}: ${state}`,
      toastProductSelected: (text) => `Selected option: ${text}`,
      toastHwConfig: (brand) => `Hardware configured for ${brand}!`,
      logFps: (val) => `[FPS Limiter] Target frequency set to ${val} Hz.`,
      logTweaks: (name, state) => `[Tweaks] ${name} has been ${state}.`,
      logOpt: (text) => `[Optimization] Parameters set: ${text}`,
      logAppStart: "[⚡] Applying hardware parameters & thermal profiles...",
      logAppSuccess: (brand, cpu) => `[✔] Configuration successfully applied for ${brand} (${cpu})!`,
      brandList: {
        samsung: "Samsung", redmagic: "ZTE Nubia RedMagic", rogphone: "Asus RogPhone",
        xiaomi: "Xiaomi / Redmi", poco: "POCO", oppo: "Oppo", oneplus: "OnePlus",
        vivo: "Vivo", huawei: "Huawei", honor: "Honor", nokia: "Nokia",
        realme: "Realme", nothing: "Nothing Phone", sony: "Sony", motorola: "Motorola",
        ihunt: "iHunt", sharp: "Sharp Aquos", other: "Universal / Other"
      },
      cpuList: {
        snapdragon: "Qualcomm Snapdragon", mediatek: "MediaTek Dimensity / Helio",
        exynos: "Samsung Exynos", kirin: "Huawei Kirin", tensor: "Google Tensor"
      },
      profileList: {
        powersave: "Battery / Eco (battery saver)",
        balanced_gaming: "Performance (medium stability)",
        performance: "Intensive Gaming (for long gaming sessions)",
        turbo: "Turbo / Extreme (active cooling required)"
      }
    },
    ru: {
      title: 'AMONESPORTS <span style="color: #ff2a2a; font-weight: bold;">BOOSTER ULTIMATE</span>',
      sysActive: "Система Активна (ON)",
      sysInactive: "Система Отключена (OFF)",
      hDaemon: "Демон (Daemon)",
      hManual: "Ручной режим (Без демона)",
      hFps: "Быстрый выбор FPS (Ограничитель Hz)",
      hGames: "Отметьте игры для разблокировки",
      gamesDesc: "Имя пакета (напр.: com.mobile.legends)",
      hLog: "Журнал событий (Лог)",
      hBrand: "Бренд смартфона",
      hCpu: "Архитектура процессора (Чипсет)",
      hRamSize: "Объем оперативной памяти RAM",
      hRamType: "Поколение оперативной памяти",
      hThermal: "Производительность CPU и нагрев",
      hNet: "Оптимизация сети и пинга (Net Boost)",
      hActions: "Быстрые действия",
      lblBrand: "Производитель устройства",
      descBrand: "Выберите бренд телефона",
      lblCpu: "Тип чипсета CPU/GPU",
      descCpu: "Оптимизация ядер процессора",
      lblRamSize: "Доступная память RAM",
      descRamSize: "Выберите объем RAM устройства",
      lblRamType: "Тип / Технология LPDDR",
      descRamType: "Частота и пропускная способность RAM",
      lblProfile: "Профиль работы и GHz",
      descProfile: "Защита от перегрева / Установка мощности",
      lblNetBoost: "Статус Net Boost",
      descNetBoost: "Снижает задержку и приоритезирует UDP",
      lblDns: "Gaming DNS & TCP Tweaks",
      descDns: "Ускоряет поток данных (Cloudflare / Google)",
      lblPkgList: "Активные пакеты на диске",
      lblFpsTarget: "Выберите кадры в секунду",
      descFpsTarget: "Лимит кадров / Частота обновления экрана",
      descDesc: "Управление железом в реальном времени, GHz, Net Boost & Thermal Guard.",
      btnApplyAll: "⚡ Настроить железо и применить",
      btnStart: "Запустить",
      btnStop: "Остановить",
      btnRestart: "Перезапустить",
      btnSave: "OK",
      btnAdd: "Добавить",
      btnApply: "Применить",
      modalSelect: "Выберите вариант",
      btnRefresh: "Обновить список",
      gamesPlaceholder: "напр.: com.mobile.legends",
      dash: "—",
      daemonLabel: "Демон:",
      tweaksLabel: "Активные твики:",
      daemonRunning: (pid, uid) => `запущен (pid ${pid}, uid ${uid || "?"})`,
      daemonStopped: "не запущен",
      stateEnabled: "включено",
      stateDisabled: "выключено",
      stateUnknown: "неизвестно",
      manualOn: "включён — демон не трогает твики, пока ты не выключишь сам",
      manualOff: "выключен — управляет демон по списку игр",
      actioning: (a) => ({ start: "Запуск…", stop: "Остановка…", restart: "Перезапуск…" }[a] || `${a}…`),
      binMissing: (bin) => `✗ Бинарник не найден или не исполняемый: ${bin}`,
      stillRunning: "✗ Всё ещё запущен",
      stopped: "✓ Остановлен",
      started: (pid, uid) => `✓ Запущен (pid ${pid}, uid ${uid || "?"})`,
      startFailed: (extra) => `✗ Не запустился.${extra} Проверь bin/fps_daemon вручную (su -c) и лог ниже.`,
      turningOn: "Включаю…",
      turningOff: "Выключаю…",
      manualOnOk: "✓ Включено вручную",
      manualOffOk: "✓ Выключено, демон снова рулит сам",
      manualNotConfirmed: "✗ Не подтвердилось — проверь лог ниже",
      toastManualOn: "FPS unlock: ручной ON",
      toastManualOff: "FPS unlock: ручной OFF",
      fpsRange: (min, max) => `Введи число от ${min} до ${max}`,
      writing: "Записываю…",
      fpsSavedOk: (expected) => `✓ Сохранено и проверено: ${expected}`,
      toastFpsSaved: (v) => `FPS сохранён: ${v} Hz`,
      fpsWriteFailed: (disk) => `✗ Запись не подтвердилась. На диске: "${disk}"`,
      toastFpsFailed: "Ошибка записи конфига",
      noValidPkg: "Ни одна строка не похожа на package name",
      empty: "Пусто",
      addingGames: "Добавляю…",
      gamesAddedOk: (n, skipped) => `✓ Добавлено и проверено: ${n}` + (skipped ? ` (пропущено некорректных: ${skipped})` : ""),
      toastGamesAdded: (n) => `Добавлено игр: ${n}`,
      gamesNotConfirmed: (list) => `✗ Не подтвердилось: ${list}`,
      removingGame: (pkg) => `Удаляю ${pkg}…`,
      removedOk: (pkg) => `✓ Удалено: ${pkg}`,
      removeFailed: (pkg) => `✗ Не удалилось: ${pkg}`,
      gamesEmpty: "список пуст",
      logEmpty: "(пусто)",
      hPopularGames: "Поддерживаемые популярные игры",
      hSaveChecked: "💾 Сохранить выбранный список",
      hAddCustom: "Добавить свою игру (Ручной пакет)",
      hCustomHz: "Свое значение Hz",
      listUpdated: (n) => `Список обновлен: сохранено игр: ${n}.`,
      langChanged: "Язык изменен на Русский",
      toastGameSelected: (name) => `Выбрана игра: ${name}`,
      toastGameRemoved: (pkg) => `Игра удалена: ${pkg}`,
      toastFpsRefresh: (val) => `Частота обновления установлена: ${val} Hz`,
      toastSetting: (name, state) => `${name}: ${state}`,
      toastProductSelected: (text) => `Выбрана опция: ${text}`,
      toastHwConfig: (brand) => `Оборудование настроено для ${brand}!`,
      logFps: (val) => `[FPS Limiter] Целевая частота установлена на ${val} Hz.`,
      logTweaks: (name, state) => `[Tweaks] ${name} был ${state}.`,
      logOpt: (text) => `[Оптимизация] Установлены параметры: ${text}`,
      logAppStart: "[⚡] Применение параметров оборудования и профилей нагрева...",
      logAppSuccess: (brand, cpu) => `[✔] Конфигурация успешно применена для ${brand} (${cpu})!`,
      brandList: {
        samsung: "Samsung", redmagic: "ZTE Nubia RedMagic", rogphone: "Asus RogPhone",
        xiaomi: "Xiaomi / Redmi", poco: "POCO", oppo: "Oppo", oneplus: "OnePlus",
        vivo: "Vivo", huawei: "Huawei", honor: "Honor", nokia: "Nokia",
        realme: "Realme", nothing: "Nothing Phone", sony: "Sony", motorola: "Motorola",
        ihunt: "iHunt", sharp: "Sharp Aquos", other: "Универсальный / Другой"
      },
      cpuList: {
        snapdragon: "Qualcomm Snapdragon", mediatek: "MediaTek Dimensity / Helio",
        exynos: "Samsung Exynos", kirin: "Huawei Kirin", tensor: "Google Tensor"
      },
      profileList: {
        powersave: "Батарея / Эко (сохранение батареи)",
        balanced_gaming: "Производительность (средняя стабильность)",
        performance: "Интенсивный гейминг (для долгих игровых сессий)",
        turbo: "Турбо / Экстрим (требуется активное охлаждение)"
      }
    }
  };

  let lang = localStorage.getItem("fps_lang");
  if (lang !== "ro" && lang !== "en" && lang !== "ru") lang = "ro";

  function t(key, ...args) {
    const v = STR[lang][key];
    return typeof v === "function" ? v(...args) : (v || key);
  }
  window.t = t;

  function stateLabel(v) {
    if (v === "enabled") return t("stateEnabled");
    if (v === "disabled") return t("stateDisabled");
    return t("stateUnknown");
  }

  function applyStaticTranslations() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      const text = t(key);
      if (text) {
        if (key === "title") {
          el.innerHTML = text;
        } else {
          el.textContent = text;
        }
      }
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.dataset.i18nPlaceholder;
      const text = t(key);
      if (text) el.placeholder = text;
    });
    document.querySelectorAll(".lang-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.lang === lang);
    });

    // Actualizează dinamic butoanele modurilor/selectoarelor dacă există funcție globală de randare opțiuni
    if (typeof window.updateActiveDropdownTexts === 'function') {
      window.updateActiveDropdownTexts();
    }
  }

  function setLanguage(newLang) {
    if (newLang === lang) return;
    lang = newLang;
    localStorage.setItem("fps_lang", lang);
    applyStaticTranslations();
    refreshDaemonDiag();
    renderGames();
    renderPresetGames();
    refreshLog();
    toast(t("langChanged"));
  }
  window.setLanguage = setLanguage;

  const $ = (id) => document.getElementById(id);

  function setStatus(el, kind, text) {
    if (!el) return;
    el.className = `status ${kind}`;
    el.textContent = text;
  }

  async function run(cmd) {
    const { errno, stdout, stderr } = await exec(cmd);
    return { ok: errno === 0, stdout: (stdout || "").trim(), stderr: (stderr || "").trim() };
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function refreshDaemonDiag() {
    const hb = await run(
      `PID=0; DUID=0; TS=0; [ -f '${STATUS_FILE}' ] && . '${STATUS_FILE}' 2>/dev/null; NOW=$(date +%s 2>/dev/null || echo 0); echo "$PID|$DUID|$((NOW-TS))"`
    );
    let [pid, uid, age] = hb.stdout.split("|");
    let isRunning = Number.isFinite(Number(age)) && Number(age) <= 15;

    if (!isRunning) {
      const lg = await run(`grep -E 'fps_daemon (started|stopped)' '${LOG_FILE}' 2>/dev/null | tail -n 1`);
      if (lg.stdout.includes("started")) {
        isRunning = true;
        const m = lg.stdout.match(/pid=(\d+)(?:,\s*uid=(\d+))?/);
        if (m) {
          pid = m[1];
          if (m[2]) uid = m[2];
        }
      }
    }

    const st = await run(`cat '${STATE_FILE}' 2>/dev/null || echo unknown`);
    const applied = st.stdout || "unknown";

    const ov = await run(`[ -f '${OVERRIDE_FILE}' ] && echo 1 || echo 0`);
    const override = ov.stdout;

    const el = $("daemonDiag");
    if (el) {
      el.innerHTML = `
        ${t("daemonLabel")} <span class="badge ${isRunning ? "on" : "off"}">${
        isRunning ? t("daemonRunning", pid, uid) : t("daemonStopped")
      }</span><br>
        ${t("tweaksLabel")} <span class="badge ${applied === "enabled" ? "on" : "off"}">${stateLabel(applied)}</span>
      `;
    }

    const toggle = $("manualToggle");
    if (toggle) toggle.checked = override === "1";
    
    const manualLabel = $("manualLabel");
    if (manualLabel) manualLabel.textContent = override === "1" ? t("manualOn") : t("manualOff");

    return { isRunning, pid, uid, applied, override };
  }

  async function daemonAction(action) {
    const statusEl = $("daemonStatus");
    setStatus(statusEl, "pending", t("actioning", action));

    if (action === "start" || action === "restart") {
      const { stdout } = await run(`[ -x '${DAEMON_BIN}' ] && echo yes || echo no`);
      if (stdout !== "yes") {
        setStatus(statusEl, "err", t("binMissing", DAEMON_BIN));
        return;
      }
    }

    const cmd = {
      start: `. '${LIB_SH}'; fps_daemon_start`,
      stop: `. '${LIB_SH}'; fps_daemon_stop`,
      restart: `. '${LIB_SH}'; fps_daemon_stop; fps_daemon_start`
    }[action];

    const { ok, stderr } = await run(cmd);

    let diag = null;
    for (let i = 0; i < 6; i++) {
      await sleep(500);
      diag = await refreshDaemonDiag();
      if (action === "stop" ? !diag.isRunning : diag.isRunning) break;
    }

    if (action === "stop") {
      setStatus(statusEl, diag.isRunning ? "err" : "ok", diag.isRunning ? t("stillRunning") : t("stopped"));
      return;
    }

    if (diag.isRunning) {
      setStatus(statusEl, "ok", t("started", diag.pid, diag.uid));
    } else {
      setStatus(statusEl, "err", t("startFailed", !ok && stderr ? ` ${stderr}` : ""));
    }
  }

  async function manualToggleChanged(turnOn) {
    const statusEl = $("manualStatus");
    const toggle = $("manualToggle");
    if (toggle) toggle.disabled = true;
    setStatus(statusEl, "pending", turnOn ? t("turningOn") : t("turningOff"));

    await run(`. '${LIB_SH}'; ${turnOn ? "fps_manual_on" : "fps_manual_off"}`);

    const wantOverride = turnOn ? "1" : "0";
    let diag = null;
    let confirmed = false;
    for (let i = 0; i < 15; i++) {
      await sleep(700);
      diag = await refreshDaemonDiag();
      if (diag.override === wantOverride) {
        confirmed = true;
        break;
      }
    }

    if (!confirmed) {
      const lg = await run(`grep -E 'manual override (active|cleared)' '${LOG_FILE}' 2>/dev/null | tail -n 1`);
      if (turnOn && lg.stdout.includes("active")) confirmed = true;
      if (!turnOn && lg.stdout.includes("cleared")) confirmed = true;
    }

    if (confirmed) {
      setStatus(statusEl, "ok", turnOn ? t("manualOnOk") : t("manualOffOk"));
      toast(turnOn ? t("toastManualOn") : t("toastManualOff"));
      if (toggle) toggle.checked = turnOn;
    } else {
      setStatus(statusEl, "err", t("manualNotConfirmed"));
      if (toggle) toggle.checked = diag.override === "1";
    }
    if (toggle) toggle.disabled = false;
  }

  async function loadFps() {
    const { stdout } = await run(`cat '${CFG_FILE}' 2>/dev/null`);
    const m = stdout.match(/FPS=(\d+)/);
    if (m && $("fpsInput")) {
      const val = m[1];
      $("fpsInput").value = val;
      highlightActiveFpsButton(val);
    }
  }

  function highlightActiveFpsButton(val) {
    document.querySelectorAll(".fps-btn").forEach(btn => {
      if (btn.getAttribute("data-fps") === String(val)) {
        btn.classList.add("highlight");
      } else {
        btn.classList.remove("highlight");
      }
    });
  }
  window.highlightActiveFpsButton = highlightActiveFpsButton;

  async function saveFps() {
    const statusEl = $("fpsStatus");
    const fpsInput = $("fpsInput");
    if (!fpsInput) return;

    const raw = fpsInput.value;
    const value = parseInt(raw, 10);

    if (!Number.isFinite(value) || value < FPS_MIN || value > FPS_MAX) {
      setStatus(statusEl, "err", t("fpsRange", FPS_MIN, FPS_MAX));
      return;
    }

    setStatus(statusEl, "pending", t("writing"));
    const expected = `FPS=${value}`;
    await run(
      `mkdir -p '${CFG_DIR}' 2>/dev/null; printf '%s\\n' '${expected}' > '${CFG_FILE}' && chmod 666 '${CFG_FILE}'`
    );

    const { stdout } = await run(`cat '${CFG_FILE}' 2>/dev/null`);
    if (stdout.trim() === expected) {
      setStatus(statusEl, "ok", t("fpsSavedOk", expected));
      toast(t("toastFpsSaved", value));
      highlightActiveFpsButton(value);
    } else {
      setStatus(statusEl, "err", t("fpsWriteFailed", stdout || t("dash")));
      toast(t("toastFpsFailed"));
    }
  }

  async function loadGames() {
    const { stdout } = await run(`cat '${GAMES_FILE}' 2>/dev/null`);
    return stdout
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith("#"));
  }

  async function renderPresetGames() {
    const container = $("presetGamesContainer");
    if (!container) return;

    const activeGames = await loadGames();
    container.innerHTML = "";

    PRESET_GAMES.forEach((game) => {
      const isChecked = activeGames.includes(game.pkg);
      const item = document.createElement("div");
      item.className = "game-check-item";

      item.innerHTML = `
        <label class="game-check-label">
          <input type="checkbox" class="game-checkbox" value="${game.pkg}" data-name="${game.name}" ${isChecked ? "checked" : ""}>
          <div>
            <div>${game.name}</div>
            <span class="pkg-subtext">${game.pkg}</span>
          </div>
        </label>
      `;
      const checkbox = item.querySelector("input");
      checkbox.addEventListener("change", (e) => {
        if (e.target.checked) {
          toast(t("toastGameSelected", game.name));
        }
      });
      container.appendChild(item);
    });
  }

  window.saveCheckedGames = async function() {
    const checkboxes = document.querySelectorAll(".game-checkbox");
    const selectedPkgs = [];
    checkboxes.forEach((cb) => {
      if (cb.checked) {
        selectedPkgs.push(cb.value);
      }
    });

    const currentOnDisk = await loadGames();
    const customPkgs = currentOnDisk.filter(
      (pkg) => !PRESET_GAMES.some((pg) => pg.pkg === pkg)
    );

    const finalGameList = [...new Set([...selectedPkgs, ...customPkgs])];
    const content = finalGameList.join("\n");

    await run(
      `mkdir -p '${CFG_DIR}' 2>/dev/null; printf '%s\\n' '${content}' > '${GAMES_FILE}' && chmod 666 '${GAMES_FILE}'`
    );

    toast(t("listUpdated", finalGameList.length));
    await renderGames();
    await renderPresetGames();
  };

  async function renderGames() {
    const listEl = $("gamesList");
    if (!listEl) return;
    const games = await loadGames();
    listEl.innerHTML = "";
    if (games.length === 0) {
      const li = document.createElement("li");
      li.className = "empty";
      li.style.justifyContent = "center";
      li.textContent = t("gamesEmpty");
      listEl.appendChild(li);
      return;
    }
    for (const pkg of games) {
      const li = document.createElement("li");
      const span = document.createElement("span");
      span.textContent = pkg;
      const btn = document.createElement("button");
      btn.textContent = "×";
      btn.onclick = () => removeGame(pkg);
      li.append(span, btn);
      listEl.appendChild(li);
    }
  }

  async function addGames() {
    const statusEl = $("gamesStatus");
    const gamesInput = $("gamesInput");
    if (!gamesInput) return;

    const raw = gamesInput.value;
    const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);

    const valid = [...new Set(lines.filter((l) => PKG_RE.test(l)))];
    const invalid = lines.filter((l) => !PKG_RE.test(l));

    if (valid.length === 0) {
      setStatus(statusEl, "err", invalid.length ? t("noValidPkg") : t("empty"));
      return;
    }

    setStatus(statusEl, "pending", t("addingGames"));
    const script = valid
      .map((p) => `grep -qxF '${p}' '${GAMES_FILE}' 2>/dev/null || echo '${p}' >> '${GAMES_FILE}'`)
      .join("; ");
    await run(`mkdir -p '${CFG_DIR}' 2>/dev/null; touch '${GAMES_FILE}'; ${script}; chmod 666 '${GAMES_FILE}'`);

    const after = await loadGames();
    const missing = valid.filter((p) => !after.includes(p));

    if (missing.length === 0) {
      setStatus(statusEl, "ok", t("gamesAddedOk", valid.length, invalid.length));
      gamesInput.value = "";
      toast(t("toastGamesAdded", valid.length));
    } else {
      setStatus(statusEl, "err", t("gamesNotConfirmed", missing.join(", ")));
    }
    await renderGames();
    await renderPresetGames();
  }

  async function removeGame(pkg) {
    const statusEl = $("gamesStatus");
    setStatus(statusEl, "pending", t("removingGame", pkg));
    await run(`grep -vxF '${pkg}' '${GAMES_FILE}' > '${GAMES_FILE}.tmp' 2>/dev/null && mv '${GAMES_FILE}.tmp' '${GAMES_FILE}'`);

    const after = await loadGames();
    if (!after.includes(pkg)) {
      setStatus(statusEl, "ok", t("removedOk", pkg));
      toast(t("toastGameRemoved", pkg));
    } else {
      setStatus(statusEl, "err", t("removeFailed", pkg));
    }
    await renderGames();
    await renderPresetGames();
  }

  async function refreshLog() {
    const box = $("logBox");
    if (!box) return;
    const { stdout } = await run(`tail -n 40 '${LOG_FILE}' 2>/dev/null`);
    box.textContent = stdout || t("logEmpty");
    box.scrollTop = box.scrollHeight;
  }

  window.addEventListener("DOMContentLoaded", () => {
    applyStaticTranslations();

    if ($("fpsSave")) $("fpsSave").onclick = saveFps;
    if ($("gamesAdd")) $("gamesAdd").onclick = addGames;
    if ($("gamesRefresh")) $("gamesRefresh").onclick = renderGames;
    if ($("daemonStart")) $("daemonStart").onclick = () => daemonAction("start");
    if ($("daemonStop")) $("daemonStop").onclick = () => daemonAction("stop");
    if ($("daemonRestart")) $("daemonRestart").onclick = () => daemonAction("restart");
    
    const manualToggle = $("manualToggle");
    if (manualToggle) {
      manualToggle.addEventListener("change", (e) => manualToggleChanged(e.target.checked));
    }

    document.querySelectorAll(".lang-btn").forEach((b) => {
      b.onclick = () => setLanguage(b.dataset.lang);
    });

    refreshDaemonDiag();
    loadFps();
    renderGames();
    renderPresetGames();
    refreshLog();
    setInterval(refreshDaemonDiag, 4000);
    setInterval(refreshLog, 4000);
  });
})();

