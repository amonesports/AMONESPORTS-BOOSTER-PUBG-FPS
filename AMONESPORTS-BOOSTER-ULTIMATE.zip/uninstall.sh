#!/system/bin/sh
MODDIR="${0%/*}"
# shellcheck disable=SC1091
if [ -f "$MODDIR/fps_lib.sh" ]; then
  . "$MODDIR/fps_lib.sh"
  fps_daemon_stop
  fps_cfg_read
  fps_apply_off "$FPS"
fi

TAG="amonkodebu"
NOTIF_ID="8642"

cmd notification cancel "$TAG" "$NOTIF_ID" 2>/dev/null
cmd notification cancel "Status" 8642 2>/dev/null
cmd notification cancel "Eroare" 8642 2>/dev/null

settings put global low_power 1 >/dev/null 2>&1
cmd power set-mode 0 >/dev/null 2>&1

rm -f /data/local/tmp/amonkodebu/orig_props.cfg \
      /data/local/tmp/amonkodebu/state \
      /data/local/tmp/amonkodebu/daemon.pid \
      /data/local/tmp/amonkodebu/daemon.lock \
      /data/local/tmp/amonkodebu/daemon.log \
      /data/local/tmp/amonkodebu/fps_daemon 2>/dev/null

cmd notification post -S bigtext -t 'AMONESPORTS BOOSTER ULTIMATE' "$TAG" '✅ Plugin Dezinstalat cu succes!  ℹ️ Daca telefonul se pune in modul Economisire baterie însemnă că pluginu-ul este șters cu succes ✌🏻 ' >/dev/null 2>&1
