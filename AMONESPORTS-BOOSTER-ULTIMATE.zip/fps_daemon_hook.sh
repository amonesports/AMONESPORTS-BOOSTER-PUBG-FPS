#!/system/bin/sh
# Called by fps_daemon (bin/fps_daemon) on foreground game<->non-game
# transitions. $1 = "on" | "off", $2 = package name (empty if the daemon
# didn't have one, e.g. future callers). Single source of truth for the
# actual tweak application stays fps_lib.sh — this is just the plumbing.
MODDIR="${0%/*}"
# shellcheck disable=SC1091
. "$MODDIR/fps_lib.sh"

fps_cfg_read
[ -n "$FPS" ] || FPS="$FPS_DEFAULT"

case "$1" in
  on)  fps_apply_on  "$FPS" "$2" ;;
  off) fps_apply_off "$FPS" "$2" ;;
  *)   exit 1 ;;
esac
