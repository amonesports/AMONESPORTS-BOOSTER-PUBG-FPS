#!/system/bin/sh
# ============================================================================
# fps_lib.sh — Logica principală pentru modulul AmonKode Unlock FPS.
# ============================================================================

FPS_PERSIST_DIR="/data/local/tmp/amonkodebu"
FPS_CFG="$FPS_PERSIST_DIR/fps.cfg"
FPS_ORIG_PROPS="$FPS_PERSIST_DIR/orig_props.cfg"
FPS_STATE="$FPS_PERSIST_DIR/state"
FPS_OVERRIDE="$FPS_PERSIST_DIR/manual_override"
FPS_GAMES_LIST="$FPS_PERSIST_DIR/games.list"
FPS_DAEMON_PID="$FPS_PERSIST_DIR/daemon.pid"
FPS_DAEMON_BIN="$FPS_PERSIST_DIR/fps_daemon"
FPS_MIN_SANE=30
FPS_MAX_SANE=260
FPS_DEFAULT=120

NOTIF_TAG="amonkodebu"
NOTIF_ID=8642

fps_show_notification() {
  local target_fps="$1"
  [ -n "$target_fps" ] || target_fps="120"
  cmd notification cancel "$NOTIF_TAG" $NOTIF_ID 2>/dev/null
  cmd notification post \
    -S bigtext \
    -i ic_dialog_info \
    -c content \
    "$NOTIF_TAG" \
    $NOTIF_ID \
    "AMONESPORTS BOOSTER ULTIMATE" \
    "Modul de înaltă performanță este ACTIVAT (${target_fps} Hz)." \
    >/dev/null 2>&1
}

fps_hide_notification() {
  cmd notification cancel "$NOTIF_TAG" $NOTIF_ID 2>/dev/null
}

fps_manual_on() {
  fps_cfg_read
  [ -n "$FPS" ] || FPS="$FPS_DEFAULT"
  echo 1 > "$FPS_OVERRIDE"
  fps_apply_on "$FPS"
}

fps_manual_off() {
  fps_cfg_read
  [ -n "$FPS" ] || FPS="$FPS_DEFAULT"
  fps_apply_off "$FPS"
  rm -f "$FPS_OVERRIDE"
}

fps_cfg_read() {
  FPS=""
  [ -f "$FPS_CFG" ] || return 1
  # shellcheck disable=SC1090
  . "$FPS_CFG" 2>/dev/null
  return 0
}

fps_cfg_write() {
  mkdir -p "$FPS_PERSIST_DIR" 2>/dev/null; chmod 777 "$FPS_PERSIST_DIR" 2>/dev/null
  echo "FPS=$1" > "$FPS_CFG"
  chmod 666 "$FPS_CFG" 2>/dev/null
}

fps_daemon_start() {
  [ -x "$FPS_DAEMON_BIN" ] || return 1
  if [ -f "$FPS_DAEMON_PID" ]; then
    local p; p="$(cat "$FPS_DAEMON_PID" 2>/dev/null)"
    [ -n "$p" ] && kill -0 "$p" 2>/dev/null && return 0
  fi
  "$FPS_DAEMON_BIN" &
  return 0
}

fps_daemon_stop() {
  [ -f "$FPS_DAEMON_PID" ] || return 0
  local p; p="$(cat "$FPS_DAEMON_PID" 2>/dev/null)"
  [ -n "$p" ] && kill -TERM "$p" 2>/dev/null
  local i=0
  while [ $i -lt 6 ] && [ -f "$FPS_DAEMON_PID" ]; do
    sleep 1
    i=$((i + 1))
  done
  [ -n "$p" ] && kill -0 "$p" 2>/dev/null && kill -KILL "$p" 2>/dev/null
  rm -f "$FPS_DAEMON_PID" 2>/dev/null
}

fps_round() {
  local val="$1" int dec
  int="${val%%.*}"
  case "$val" in
    *.*) dec="${val#*.}"; dec="${dec%%[!0-9]*}" ;;
    *) dec="" ;;
  esac
  case "$int" in ''|*[!0-9]*) int=0 ;; esac
  case "$dec" in
    [5-9]*) int=$((int + 1)) ;;
  esac
  echo "$int"
}

fps_detect() {
  local raw cand best
  command -v dumpsys >/dev/null 2>&1 || return 1
  raw="$(dumpsys display 2>/dev/null)"
  [ -n "$raw" ] || return 1

  cand="$(printf '%s\n' "$raw" | grep -oE 'refreshRate=[0-9]+(\.[0-9]+)?' | grep -oE '[0-9]+(\.[0-9]+)?')"
  if [ -z "$cand" ]; then
    cand="$(printf '%s\n' "$raw" | grep -oE '[0-9]+(\.[0-9]+)?fps' | grep -oE '^[0-9]+(\.[0-9]+)?')"
  fi
  [ -n "$cand" ] || return 1

  best="$(printf '%s\n' "$cand" | sort -rn | head -1)"
  [ -n "$best" ] || return 1
  best="$(fps_round "$best")"
  case "$best" in ''|*[!0-9]*) return 1 ;; esac
  [ "$best" -ge "$FPS_MIN_SANE" ] && [ "$best" -le "$FPS_MAX_SANE" ] || return 1

  echo "$best"
  return 0
}

FPS_PICKED=""
pick_fps_manual() {
  local presets="60 90 90.5 120 144 165 180 240"
  local total_timeout=25 idx=4 n cur t0 tnow events
  set -- $presets; n=$#
  eval "cur=\${$idx}"
  ui_print " "
  ui_print "Autodetectarea a eșuat - alege manual:"
  ui_print "   VOLUM JOS - valoarea următoare | VOLUM SUS - confirmă"
  ui_print "   Fără opțiune timp de ${total_timeout}s -> se alege implicit ${FPS_DEFAULT} Hz"
  ui_print "   -> ${cur} Hz"
  t0=$(date +%s)
  while :; do
    tnow=$(date +%s)
    if [ $((tnow - t0)) -ge "$total_timeout" ]; then
      FPS_PICKED="$FPS_DEFAULT"; return 0
    fi
    events="$TMPDIR/fps_pick_events"
    timeout 1 /system/bin/getevent -lqc 1 > "$events" 2>&1
    if grep -q 'KEY_VOLUMEUP *DOWN' "$events"; then
      FPS_PICKED="$(fps_round "$cur")"; return 0
    fi
    if grep -q 'KEY_VOLUMEDOWN *DOWN' "$events"; then
      idx=$((idx + 1)); [ "$idx" -gt "$n" ] && idx=1
      eval "cur=\${$idx}"
      ui_print "   -> ${cur} Hz"
    fi
  done
}

SPOOF_KEYS="ro.product.model ro.product.odm.model ro.product.system.model ro.product.vendor.model ro.product.system_ext.model ro.product.brand ro.product.name ro.product.device ro.product.manufacturer ro.product.board ro.board.platform ro.build.fingerprint ro.vendor.build.fingerprint"

BUILD_PROP_PATHS="/system/build.prop /system/system/build.prop /vendor/build.prop /vendor/odm/etc/build.prop /odm/etc/build.prop /odm/build.prop /product/build.prop /product/etc/build.prop /system_ext/build.prop /system_ext/etc/build.prop"

fps_read_stock_prop() {
  local key="$1" f v
  for f in $BUILD_PROP_PATHS; do
    [ -f "$f" ] || continue
    v="$(grep -m1 "^${key}=" "$f" 2>/dev/null | cut -d'=' -f2-)"
    if [ -n "$v" ]; then
      echo "$v"
      return 0
    fi
  done
  getprop "$key" 2>/dev/null
}

fps_capture_orig_props() {
  mkdir -p "$FPS_PERSIST_DIR" 2>/dev/null; chmod 777 "$FPS_PERSIST_DIR" 2>/dev/null
  : > "$FPS_ORIG_PROPS"
  local k v
  for k in $SPOOF_KEYS; do
    v="$(fps_read_stock_prop "$k")"
    echo "$k=$v" >> "$FPS_ORIG_PROPS"
  done
  chmod 666 "$FPS_ORIG_PROPS" 2>/dev/null
}

fps_apply_spoof() {
    resetprop ro.product.model "RedMagic 11 Pro"
  resetprop ro.product.odm.model "RedMagic 11 Pro"
  resetprop ro.product.system.model "RedMagic 11 Pro"
  resetprop ro.product.vendor.model "RedMagic 11 Pro"
  resetprop ro.product.system_ext.model "RedMagic 11 Pro"
  resetprop ro.product.brand "nubia"
  resetprop ro.product.name "nx_global"
  resetprop ro.product.device "NX789J"
  resetprop ro.product.manufacturer "nubia"
  resetprop ro.product.board "kalama"
  resetprop ro.board.platform "kalama"
  resetprop ro.build.fingerprint "nubia/NX789J/NX789J:15/AP3A.240617.008/eng.build.2025:user/release-keys"
  resetprop ro.vendor.build.fingerprint "nubia/NX789J/NX789J:15/AP3A.240617.008/eng.build.2025:user/release-keys"

}

fps_revert_spoof() {
  [ -f "$FPS_ORIG_PROPS" ] || return 1
  local k v
  while IFS='=' read -r k v; do
    [ -n "$k" ] || continue
    resetprop "$k" "$v" 2>/dev/null
  done < "$FPS_ORIG_PROPS"
  return 0
}

fps_apply_on() {
  local FPS="$1"
  local PKG="$2"
  [ -n "$FPS" ] || FPS="$FPS_DEFAULT"

  fps_apply_spoof

  setprop debug.performance.tuning 1
  setprop debug.gr.numframebuffers 3
  setprop debug.hwui.target_cpu_time_percent 100
  setprop debug.hwui.level 0
  setprop debug.hwui.profile false
  setprop debug.hwui.skip_empty_damage true
  setprop debug.hwui.filter_test_overhead false
  setprop debug.hwui.use_gpu_pixel_buffers true
  setprop debug.hwui.capture_skp_enabled false
  setprop debug.hwui.trace_gpu_resources false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop renderthread.skia.reduceopstasksplitting true
  setprop debug.hwui.webview_overlays_enabled false
  setprop debug.hwui.drawing_enabled true
  setprop debug.hwui.use_hint_manager true
  setprop debug.hwui.app_memory_policy aggressive
  setprop debug.hwui.8bit_hdr_headroom 0
  setprop debug.hwui.initialize_gl_always true
  setprop debug.hwui.skip_eglmanager_telemetry true
  setprop debug.hwui.early_preload_gl_context true
  setprop debug.hwui.use_buffer_age true
  setprop debug.hwui.use_partial_updates true
  setprop debug.hwui.disable_vsync true
  setprop debug.hwui.force_draw_frame true
  setprop debug.hwui.enable_partial_updates true
  setprop debug.hwui.override_gpu_tracking true
  setprop debug.renderengine.graphite_preview_optin true
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.capture_filename ""
  setprop debug.renderengine.blur_algorithm none
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.sf.set_idle_timer_ms 0
  setprop debug.sf.set_idle_timer_ms_0 0
  setprop debug.sf.support_kernel_idle_timer_0 true
  setprop debug.sf.enable_layer_caching true
  setprop debug.sf.disable_client_composition_cache false
  setprop debug.sf.predict_hwc_composition_strategy 1
  setprop debug.sf.treat_170m_as_sRGB 1
  setprop debug.sf.dim_in_gamma_in_enhanced_screenshots 0
  setprop debug.sf.ignore_hwc_physical_display_orientation true
  setprop debug.sf.enable_gl_backpressure 0
  setprop debug.sf.use_frame_rate_priority 1
  setprop debug.sf.luma_sampling 1
  setprop debug.sf.treble_testing_override true
  setprop debug.sf.auto_latch_unsignaled true
  setprop debug.sf.hwc_service_name default
  setprop debug.sf.enable_hwc_vds 0
  setprop debug.sf.latch_unsignaled 1
  setprop debug.sf.hw 1
  setprop debug.egl.hw 1
  setprop debug.egl.buffercount 3
  setprop debug.gralloc.map_fb_memory 0
  setprop debug.gralloc.gfx_ubwc_disable 0
  setprop debug.gralloc.enable_fb_ubwc 1
  setprop debug.graphics.game_default_frame_rate.disabled 1
  setprop debug.graphics.hint_session_cts_api_override 1
  setprop debug.hwc.use_rate_limiter false
  setprop debug.hwc.bq_count 3
  setprop debug.hwc.compose_level 3
  setprop debug.hwc.nodirtyregion 1
  setprop debug.hwc.dynThreshold 2.0
  setprop debug.perf_event_max_sample_rate 0
  setprop debug.perf_cpu_time_max_percent 0
  setprop debug.perf_event_mlock_kb 0
  setprop debug.sf.frame_rate_multiple_threshold 0
  setprop debug.sf.stable_edid_ids 0
  setprop debug.sf.multithreaded_present 1
  setprop debug.egl.swapbehavior 0
  setprop debug.gl.disable_batching 0
  setprop debug.gl.profiler 0
  setprop debug.gl.buffer_age 1
  setprop debug.sf.vsync_reactor_ignore_present_fences true
  setprop debug.sf.late_sf_use_app_refresh 0
  setprop debug.sf.useSmart90ForVideo 0
  setprop debug.qc.hardware true
  setprop debug.qctwa.statusbar 1
  setprop debug.qctwa.preservebuf 1
  setprop debug.sf.showupdates 0
  setprop debug.sf.showcpu 0
  setprop debug.sf.showbackground 0
  setprop debug.sf.showfps 0

  setprop debug.refresh_rate.min_fps "$FPS"
  setprop debug.refresh_rate.max_fps "$FPS"
  setprop debug.refresh_rate.peak_fps "$FPS"
  setprop debug.display.allow_non_native_refresh_rate_override true
  setprop debug.display.render_frame_rate_is_physical_refresh_rate true
  setprop debug.hwc.force_gpu 0
  setprop debug.sf.high_fps_late_app_phase_offset_ns -5000000
  setprop debug.sf.high_fps_late_sf_phase_offset_ns -5000000
  setprop debug.sf.high_fps_early_phase_offset_ns -5000000
  setprop debug.sf.high_fps_early_gl_phase_offset_ns -5000000
  setprop debug.sf.high_fps_early_app_phase_offset_ns -5000000
  setprop debug.sf.early_gl_app_phase_offset_ns -5000000
  setprop debug.sf.early_phase_offset_ns -5000000
  setprop debug.sf.early_gl_phase_offset_ns -5000000
  setprop debug.sf.early_app_phase_offset_ns -5000000
  setprop debug.sf.late.app.duration 0
  setprop debug.sf.early.sf.duration -5000000
  setprop debug.sf.early.app.duration -5000000
  setprop debug.sf.earlyGl.sf.duration -5000000
  setprop debug.sf.earlyGl.app.duration -5000000
  setprop debug.sf.hwc.min.duration -1000000
  setprop debug.touch_sensitivity_mode 1
  setprop debug.hwui.profile.maxframes "$FPS"
  setprop debug.hwui.fpslimit "$FPS"
  setprop debug.hwui.fps_limit "$FPS"
  setprop debug.sf.scroll_boost_refreshrate "$FPS"
  setprop debug.sf.touch_boost_refreshrate "$FPS"
  setprop "debug.sf.prim_perf_${FPS}hz_base_brightness_zone" "${FPS}:${FPS}:${FPS},${FPS}:${FPS}:${FPS},${FPS}:${FPS}:${FPS}"
  setprop debug.sf.prim_std_brightness_zone "${FPS}:${FPS}:${FPS},${FPS}:${FPS}:${FPS}"
  setprop debug.sf.cli_perf_brightness_zone "${FPS}:${FPS}:${FPS}"
  setprop debug.sf.cli_std_brightness_zone "${FPS}:${FPS}:${FPS}"

  settings put system db_screen_rate 2
  settings put system perf_proc_threshold 0
  settings put system perf_proc_power 0
  settings put system perf_shielder_Proc 0
  settings put system POWER_PERFORMANCE_MODE_OPEN 1
  settings put system multicore_packet_scheduler 1
  settings put system high_performance_mode_on 1
  settings put system sem_performance_mode 4
  settings put system speed_mode 1
  settings put secure high_priority 1
  settings put secure speed_mode_enable 1
  settings put global sem_enchanced_cpu_responsiveness 1
  settings put global cached_apps_freezer "enabled"
  settings put global restricted_device_performance "0,0"
  settings put global adaptive_battery_management_enabled 0
  settings put global game_auto_temperature_control 0
  settings put system perf_shielder_SF 0
  settings put system perf_shielder_RTMODE 1
  settings put system perf_shielder_GESTURE 0
  settings put system perf_shielder_smartpower 0
  settings put system screen_game_mode 1
  settings put secure gb_boosting 1
  settings put system POWER_SAVE_MODE_OPEN 0
  settings put global automatic_power_save_mode 0
  settings put global low_power 0
  settings put system framepredict_enable 1
  settings put system is_smart_fps 0
  settings put system screen_optimize_mode 1
  settings put system fstb_target_fps_margin_high_fps 20
  settings put system fstb_target_fps_margin_low_fps 20
  settings put system gcc_fps_margin 10
  settings put secure support_highfps 1
  settings put system peak_refresh_rate 1
  settings put system user_refresh_rate "$FPS"
  settings put system min_refresh_rate "$FPS"
  settings put system thermal_limit_refresh_rate 0
  settings put system miui_refresh_rate "$FPS"
  settings put secure user_refresh_rate 1
  settings put secure max_refresh_rate "$FPS"
  settings put secure miui_refresh_rate "$FPS"
  settings put secure match_content_frame_rate 0
  settings put secure refresh_rate_mode 2
  settings put system ext_force_refresh_rate_list "$FPS"

  cmd display set-match-content-frame-rate-pref 0
  cmd power set-fixed-performance-mode-enabled true
  cmd power set-adaptive-power-saver-enabled false
  cmd power set-mode 0

  settings put global game_driver_all_apps 1

  if [ -n "$PKG" ]; then
    device_config put game_overlay "$PKG" "mode=2"
    cmd game mode performance "$PKG"
  fi

  fps_show_notification "$FPS"
  echo "enabled" > "$FPS_STATE"
}

fps_apply_off() {
  local FPS="$1"
  local PKG="$2"
  setprop debug.performance.tuning 0
  setprop debug.gr.numframebuffers 2
  setprop debug.hwui.target_cpu_time_percent 50
  setprop debug.hwui.level 1
  setprop debug.hwui.profile false
  setprop debug.hwui.skip_empty_damage false
  setprop debug.hwui.filter_test_overhead true
  setprop debug.hwui.use_gpu_pixel_buffers false
  setprop debug.hwui.capture_skp_enabled false
  setprop debug.hwui.trace_gpu_resources false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop renderthread.skia.reduceopstasksplitting false
  setprop debug.hwui.webview_overlays_enabled true
  setprop debug.hwui.drawing_enabled true
  setprop debug.hwui.use_hint_manager false
  setprop debug.hwui.app_memory_policy balanced
  setprop debug.hwui.8bit_hdr_headroom 2
  setprop debug.hwui.initialize_gl_always false
  setprop debug.hwui.skip_eglmanager_telemetry false
  setprop debug.hwui.early_preload_gl_context false
  setprop debug.hwui.use_buffer_age false
  setprop debug.hwui.use_partial_updates false
  setprop debug.hwui.disable_vsync false
  setprop debug.hwui.force_draw_frame false
  setprop debug.hwui.enable_partial_updates false
  setprop debug.hwui.override_gpu_tracking false
  setprop debug.renderengine.graphite_preview_optin false
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.capture_filename ""
  setprop debug.renderengine.blur_algorithm default
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.sf.set_idle_timer_ms 5000
  setprop debug.sf.set_idle_timer_ms_0 5000
  setprop debug.sf.support_kernel_idle_timer_0 false
  setprop debug.sf.enable_layer_caching true
  setprop debug.sf.disable_client_composition_cache false
  setprop debug.sf.predict_hwc_composition_strategy 0
  setprop debug.sf.treat_170m_as_sRGB 0
  setprop debug.sf.dim_in_gamma_in_enhanced_screenshots 1
  setprop debug.sf.ignore_hwc_physical_display_orientation false
  setprop debug.sf.enable_gl_backpressure 1
  setprop debug.sf.use_frame_rate_priority 0
  setprop debug.sf.luma_sampling 0
  setprop debug.sf.treble_testing_override false
  setprop debug.sf.auto_latch_unsignaled false
  setprop debug.sf.hwc_service_name default
  setprop debug.sf.enable_hwc_vds 1
  setprop debug.sf.latch_unsignaled 0
  setprop debug.sf.hw 0
  setprop debug.egl.hw 0
  setprop debug.egl.buffercount 1
  setprop debug.gralloc.map_fb_memory 1
  setprop debug.gralloc.gfx_ubwc_disable 1
  setprop debug.gralloc.enable_fb_ubwc 0
  setprop debug.graphics.game_default_frame_rate.disabled false
  setprop debug.graphics.hint_session_cts_api_override 0
  setprop debug.hwc.use_rate_limiter true
  setprop debug.hwc.bq_count 0
  setprop debug.hwc.compose_level 0
  setprop debug.hwc.nodirtyregion 0
  setprop debug.hwc.dynThreshold 1.0
  setprop debug.perf_event_max_sample_rate 1000
  setprop debug.perf_cpu_time_max_percent 100
  setprop debug.perf_event_mlock_kb 0
  setprop debug.sf.frame_rate_multiple_threshold 1
  setprop debug.sf.stable_edid_ids 1
  setprop debug.sf.multithreaded_present 0
  setprop debug.egl.swapbehavior 1
  setprop debug.gl.disable_batching 1
  setprop debug.gl.profiler 0
  setprop debug.gl.buffer_age 0
  setprop debug.sf.vsync_reactor_ignore_present_fences false
  setprop debug.sf.late_sf_use_app_refresh 1
  setprop debug.sf.useSmart90ForVideo 1
  setprop debug.qc.hardware false
  setprop debug.qctwa.statusbar 0
  setprop debug.qctwa.preservebuf 0
  setprop debug.sf.showupdates 1
  setprop debug.sf.showcpu 1
  setprop debug.sf.showbackground 1
  setprop debug.sf.showfps 1

  setprop debug.refresh_rate.min_fps 0
  setprop debug.refresh_rate.max_fps 0
  setprop debug.refresh_rate.peak_fps 0
  setprop debug.sf.high_fps_late_app_phase_offset_ns 0
  setprop debug.sf.high_fps_late_sf_phase_offset_ns 0
  setprop debug.sf.high_fps_early_phase_offset_ns 0
  setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
  setprop debug.sf.high_fps_early_app_phase_offset_ns 0
  setprop debug.sf.early_gl_app_phase_offset_ns 0
  setprop debug.sf.early_phase_offset_ns 0
  setprop debug.sf.early_gl_phase_offset_ns 0
  setprop debug.sf.early_app_phase_offset_ns 0
  setprop debug.sf.late.app.duration 0
  setprop debug.sf.early.sf.duration 0
  setprop debug.sf.early.app.duration 0
  setprop debug.sf.earlyGl.sf.duration 0
  setprop debug.sf.earlyGl.app.duration 0
  setprop debug.sf.hwc.min.duration 0
  setprop debug.touch_sensitivity_mode 0

  settings put system db_screen_rate 0
  settings put system perf_proc_threshold 50
  settings put system perf_proc_power 50
  settings put system perf_shielder_Proc 1
  settings put system POWER_PERFORMANCE_MODE_OPEN 0
  settings put system multicore_packet_scheduler 0
  settings put system high_performance_mode_on 0
  settings put system sem_performance_mode 0
  settings put system speed_mode 0
  settings put secure high_priority 0
  settings put secure speed_mode_enable 0
  settings put global sem_enchanced_cpu_responsiveness 0
  settings put global cached_apps_freezer disabled
  settings put global restricted_device_performance 1,1
  settings put global adaptive_battery_management_enabled 1
  settings put global game_auto_temperature_control 1
  settings put system perf_shielder_SF 1
  settings put system perf_shielder_RTMODE 0
  settings put system perf_shielder_GESTURE 1
  settings put system perf_shielder_smartpower 1
  settings put system screen_game_mode 0
  settings put secure gb_boosting 0

  settings put system POWER_SAVE_MODE_OPEN 0
  settings put global automatic_power_save_mode 0
  settings put global low_power 0

  settings put system framepredict_enable 0
  settings put system is_smart_fps 1
  settings put system screen_optimize_mode 0
  settings put system fstb_target_fps_margin_high_fps 0
  settings put system fstb_target_fps_margin_low_fps 0
  settings put system gcc_fps_margin 0
  settings put secure support_highfps 0
  settings put system peak_refresh_rate 0
  settings put system user_refresh_rate 0
  settings put system min_refresh_rate 0
  settings put system thermal_limit_refresh_rate 60
  settings put system miui_refresh_rate 0
  settings put secure user_refresh_rate 0
  settings put secure max_refresh_rate 0
  settings put secure miui_refresh_rate 0
  settings put secure match_content_frame_rate 1
  settings put secure refresh_rate_mode 1
  settings put system ext_force_refresh_rate_list 0

  setprop debug.hwui.profile.maxframes 0
  setprop debug.hwui.fpslimit 0
  setprop debug.hwui.fps_limit 0
  setprop debug.display.allow_non_native_refresh_rate_override false
  setprop debug.display.render_frame_rate_is_physical_refresh_rate false
  setprop debug.sf.scroll_boost_refreshrate 0
  setprop debug.sf.touch_boost_refreshrate 0
  [ -n "$FPS" ] && setprop "debug.sf.prim_perf_${FPS}hz_base_brightness_zone" ""
  setprop debug.sf.prim_std_brightness_zone ""
  setprop debug.sf.cli_perf_brightness_zone ""
  setprop debug.sf.cli_std_brightness_zone ""

  cmd display set-match-content-frame-rate-pref 1
  cmd power set-fixed-performance-mode-enabled false
  cmd power set-adaptive-power-saver-enabled false
  cmd power set-mode 0

  settings put global game_driver_all_apps 0
  if [ -n "$PKG" ]; then
    cmd game mode standard "$PKG"
  fi

  fps_revert_spoof
  fps_hide_notification
  echo "disabled" > "$FPS_STATE"
}

